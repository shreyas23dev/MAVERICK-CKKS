#!/usr/bin/env bash
# Downloads MP-SPDZ v0.4.0 (official static binaries), installs the MAVERICK programs and compiles them.
# Usage: scripts/setup_mpspdz.sh [k values for decrypt, default "4 34 44 46"]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MP="${MPSPDZ_DIR:-$ROOT/third_party/mp-spdz-0.4.0}"
KS="${*:-4 34 44 46}"
Q0=576460752303439873; PBIG=170141183460469231731687303715885907969
if [ ! -x "$MP/mascot-party.x" ]; then
  mkdir -p "$(dirname "$MP")"; cd "$(dirname "$MP")"
  curl -sSL -o mp-spdz-0.4.0.tar.xz https://github.com/data61/MP-SPDZ/releases/download/v0.4.0/mp-spdz-0.4.0.tar.xz
  tar xf mp-spdz-0.4.0.tar.xz
  cp "$MP/bin/Linux-amd64/mascot-party.x" "$MP/"
fi
cd "$MP"
[ -f Player-Data/P0.pem ] || Scripts/setup-ssl.sh 4 >/dev/null 2>&1
cp "$ROOT"/mpc/mpspdz_programs/* Programs/Source/
mkdir -p Programs/Public-Input Persistence
./compile.py -P $Q0 keygen 4096 >/dev/null
for k in $KS; do ./compile.py -P $Q0 decrypt 4096 "$k" >/dev/null; done
./compile.py -P $Q0 verify 4096 >/dev/null
./compile.py -P $PBIG modred 256 >/dev/null
echo "MP-SPDZ ready at $MP (keygen, decrypt k=[$KS], verify, modred compiled)"
