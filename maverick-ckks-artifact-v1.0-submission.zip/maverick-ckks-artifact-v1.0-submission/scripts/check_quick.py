"""Compares the quick reproduction against the frozen results used in the paper."""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
Q = os.path.join(ROOT, 'results', 'quick'); F = os.path.join(ROOT, 'data', 'frozen')
ok = True
def check(name, cond, detail):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}: {detail}")
new = [json.loads(l) for l in open(f'{Q}/mascot_runs/quick_n2/log.jsonl')]
old = [json.loads(l) for l in open(f'{F}/mascot_runs/n2_val/log.jsonl')]
nd = [r for r in new if r['stage'] == 'decrypt'][0]; od = [r for r in old if r['stage'] == 'decrypt'][0]
check('E10 MASCOT keygen+decrypt n=2 k=4', all(r['rc'] == 0 for r in new) and abs(nd['log2RMSE'] - od['log2RMSE']) < 0.1,
      f"log2RMSE new {nd['log2RMSE']:.3f} vs frozen {od['log2RMSE']:.3f}")
t = json.load(open(f'{Q}/mascot_runs/quick_tamper/tamper.json'))['results']
ctrl = [r for r in t if r['kind'] == 'control']; att = [r for r in t if r['kind'] != 'control']
check('E11 MASCOT tampering', all(r['accepted'] for r in ctrl) and not any(r['accepted'] for r in att) and all(r['mac_msg'] for r in att),
      f"controls accepted {sum(r['accepted'] for r in ctrl)}/{len(ctrl)}, attacks rejected with MacCheck {sum(r['mac_msg'] for r in att)}/{len(att)}")
a = [json.loads(l) for l in open(f'{Q}/attack.jsonl')]
none = [r for r in a if r['mode'] == 'none'][0]; sm = [r for r in a if r['mode'] != 'none']
check('E3 key recovery', none['fullRecoveries'] == none['trials'] and all(r['fullRecoveries'] == 0 for r in sm),
      f"no smudging {none['fullRecoveries']}/{none['trials']}, smudged {sum(r['fullRecoveries'] for r in sm)} recoveries")
pn = json.load(open(f'{Q}/py_results.json')); po = json.load(open(f'{F}/lattigo_python/py_results.json'))
check('E5-E9 Python (seeded, must be identical)', json.dumps(pn, sort_keys=True) == json.dumps(po, sort_keys=True), 'byte-identical JSON' if pn == po else 'differs')
print('ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'); sys.exit(0 if ok else 1)
