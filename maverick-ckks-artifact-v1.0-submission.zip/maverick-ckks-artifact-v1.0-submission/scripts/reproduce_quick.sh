#!/usr/bin/env bash
# Quick reproduction (~15-25 min on 2 vCPU): one MASCOT key generation + decryption (n=2, k=4),
# a short tampering test, the Lattigo key-recovery test, and the exact/emulated Python experiments.
# Results go to results/quick/ and are checked against data/frozen/ by scripts/check_quick.py.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
export MAV_RUNS="$ROOT/results/quick/mascot_runs"; mkdir -p "$MAV_RUNS" results/quick
scripts/build_go.sh
scripts/setup_mpspdz.sh 4
python3 mpc/pipeline.py 2 4 quick_n2
python3 mpc/tamper.py 2 2 quick_tamper
(cd lattigo_harness && ./mav -exp attack -reps 3 > "$ROOT/results/quick/attack.jsonl")
python3 python_experiments/py_experiments.py results/quick/py_results.json > results/quick/py_experiments.log
python3 scripts/check_quick.py
