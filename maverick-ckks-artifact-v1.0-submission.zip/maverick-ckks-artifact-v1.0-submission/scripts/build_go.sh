#!/usr/bin/env bash
# Builds the Lattigo harness (E1-E4) and the Lattigo glue used by the MASCOT pipeline.
set -euo pipefail
cd "$(dirname "$0")/.."
export GOFLAGS=${GOFLAGS:--mod=mod}
# If proxy.golang.org / golang.org are unreachable, the go.mod replace lines resolve via GitHub mirrors:
# export GOPROXY=direct GOSUMDB=off
(cd lattigo_harness && go build -o mav .)
(cd mpc/glue && go build -o glue .)
echo "built lattigo_harness/mav and mpc/glue/glue"
