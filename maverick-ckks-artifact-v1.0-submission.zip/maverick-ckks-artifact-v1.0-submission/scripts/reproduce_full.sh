#!/usr/bin/env bash
# Full reproduction of every experiment in the paper (several hours on 2 vCPU; MASCOT dominates).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
OUT="$ROOT/results/full"; export MAV_RUNS="$OUT/mascot_runs"; mkdir -p "$MAV_RUNS" "$OUT/figures" "$OUT/csv"
scripts/build_go.sh
scripts/setup_mpspdz.sh 4 34 44 46
# E1-E4: Lattigo
(cd lattigo_harness && ./mav -exp precision -reps 5 > "$OUT/precision.jsonl" && ./mav -exp timing -reps 15 > "$OUT/timing.jsonl" \
  && ./mav -exp attack -reps 20 > "$OUT/attack.jsonl" && ./mav -exp feasible -reps 10 > "$OUT/feasible.jsonl")
# E5-E9 and A7
python3 python_experiments/py_experiments.py "$OUT/py_results.json"
python3 python_experiments/modred_wrap.py "$OUT/modred_wrap.json"
# E10-E12: MASCOT
python3 mpc/pipeline.py 2 4 n2_val
python3 mpc/pipeline.py 2 34,44 n2_main
python3 mpc/pipeline.py 3 44 n3_main
python3 mpc/tamper.py 3 10 n3_tamper
python3 mpc/modred_run.py 256
python3 mpc/pipeline.py 2 46 n2_lam20
python3 mpc/tamper.py 2 10 n2_tamper
# Figures, CSVs, LaTeX tables
python3 python_experiments/analyze.py "$OUT" "$OUT/figures"
python3 figures_and_tables/mascot_figs.py "$MAV_RUNS" "$OUT/figures"
python3 figures_and_tables/export_csv.py "$OUT" "$MAV_RUNS" "$OUT/csv"
python3 figures_and_tables/make_tex.py "$OUT" "$MAV_RUNS" "$OUT/modred_wrap.json"
echo "done: $OUT"
