"""E12: masked modular-reduction gadget under MASCOT (2 parties, 128-bit field, two 60-bit RNS limbs).
Usage: modred_run.py [M=256]"""
import json, os, random, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.abspath(__file__))
MP = os.environ.get('MPSPDZ_DIR', os.path.join(ROOT, '..', 'third_party', 'mp-spdz-0.4.0'))
RUNS = os.environ.get('MAV_RUNS', os.path.join(ROOT, '..', 'results', 'mascot_runs')); os.makedirs(RUNS, exist_ok=True)
P = 170141183460469231731687303715885907969
QS = [576460752303439873, 576460752303702017]; M = int(sys.argv[1]) if len(sys.argv) > 1 else 256; X = 2**73
rng = random.Random(99); xs = [rng.randrange(-X, X) for _ in range(M)]
hi = [(x + X) >> 37 for x in xs]; lo = [(x + X) & ((1 << 37) - 1) for x in xs]
os.makedirs(f'{MP}/Player-Data', exist_ok=True)
open(f'{MP}/Player-Data/Input-P0-0', 'w').write(' '.join(map(str, hi + lo)) + '\n')
t0 = time.time(); r = subprocess.run(['Scripts/mascot.sh', '-N', '2', '-P', str(P), f'modred-{M}'], cwd=MP, capture_output=True, text=True)
out = r.stdout + r.stderr; open(f'{RUNS}/modred.out', 'w').write(out)
res = dict(M=M, wall_s=time.time() - t0, rc=r.returncode)
m = re.search(r'Time = ([\d.]+) seconds', out); d = re.search(r'Global data sent = ([\d.]+) MB', out)
res['mpc_time_s'] = float(m.group(1)) if m else None; res['global_MB'] = float(d.group(1)) if d else None
for l, q in enumerate(QS):
    ys = [int(v) for v in re.findall(rf'^Y{l} (-?\d+)$', out, re.M)]
    res[f'limb{l}_n'] = len(ys); res[f'limb{l}_correct'] = sum((y % P) % q == x % q for y, x in zip(ys, xs))
json.dump(res, open(f'{RUNS}/modred.json', 'w')); print(json.dumps(res))
