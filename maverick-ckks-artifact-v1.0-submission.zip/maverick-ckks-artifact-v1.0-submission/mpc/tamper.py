"""Active-tampering tests against real MASCOT runs (separate party processes over TCP).
A corrupted party modifies its persisted authenticated key share (value, MAC, or both with a
guessed MAC key) and the parties run verify-<N>; MASCOT's MAC check must abort.
Usage: tamper.py <n_parties> <trials_per_kind> <tag>"""
import os, random, re, shutil, struct, subprocess, sys, json, time
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
MP = os.environ.get('MPSPDZ_DIR', os.path.join(ROOT, '..', 'third_party', 'mp-spdz-0.4.0'))
RUNS = os.environ.get('MAV_RUNS', os.path.join(ROOT, '..', 'results', 'mascot_runs'))
from nttlib import Q0
N = 4096; HDR = 37
n = int(sys.argv[1]); T = int(sys.argv[2]); tag = sys.argv[3]
W = os.path.join(RUNS, tag); os.makedirs(W, exist_ok=True)
rng = random.Random(2026)
files = [f'{MP}/Persistence/Transactions-P{i}.data' for i in range(n)]
for f in files: shutil.copy(f, f + '.orig')
assert os.path.getsize(files[0]) == HDR + 16 * N

def run():
    t0 = time.time()
    r = subprocess.run(['Scripts/mascot.sh', '-N', str(n), '-P', str(Q0), f'verify-{N}'], cwd=MP, capture_output=True, text=True, timeout=900)
    out = r.stdout + r.stderr
    for i in range(1, n):  # parties 1..n-1 write to logs/-N-<i> under Scripts/mascot.sh
        try: out += open(f'{MP}/logs/-N-{i}').read()
        except OSError: pass
    ok = re.search(r'^Y -?\d+', out, re.M) is not None and r.returncode == 0
    mac = 'MacCheck Failure' in out
    return dict(accepted=ok, rc=r.returncode, mac_msg=mac, wall_s=time.time() - t0)

def patch(party, idx, kind):
    f = files[party]; b = bytearray(open(f + '.orig', 'rb').read())
    off = HDR + 16 * idx
    v = struct.unpack_from('<Q', b, off)[0]; m = struct.unpack_from('<Q', b, off + 8)[0]
    d = rng.randrange(1, Q0)
    if kind in ('value', 'both'): struct.pack_into('<Q', b, off, (v + d) % Q0)
    if kind in ('mac', 'both'): struct.pack_into('<Q', b, off + 8, (m + rng.randrange(1, Q0)) % Q0)
    open(f, 'wb').write(b)

res = []
for kind in ['control', 'value', 'mac', 'both']:
    for t in range(T):
        party = rng.randrange(n); idx = rng.randrange(N)
        for f in files: shutil.copy(f + '.orig', f)
        if kind != 'control': patch(party, idx, kind)
        r = run(); r.update(kind=kind, party=party, index=idx, trial=t)
        res.append(r); print(json.dumps(r), flush=True)
for f in files: shutil.copy(f + '.orig', f)
summ = {k: dict(trials=sum(1 for r in res if r['kind'] == k), accepted=sum(r['accepted'] for r in res if r['kind'] == k),
                median_wall_s=sorted(r['wall_s'] for r in res if r['kind'] == k)[T // 2]) for k in ['control', 'value', 'mac', 'both']}
json.dump(dict(n=n, results=res, summary=summ), open(f'{W}/tamper.json', 'w'), indent=1)
print(json.dumps(summ))
