"""Negacyclic NTT over Z_q (Longa--Naehrig CT forward / GS inverse), shared by the
Python reference, the MP-SPDZ programs (imported at compile time) and the orchestrator."""
Q0 = 576460752303439873  # 60-bit prime, q0 = 1 mod 2^14; also the MASCOT field


def _bitrev(x, bits):
    return int(format(x, f'0{bits}b')[::-1], 2)


def find_psi(N, q=Q0):
    for g in range(2, 10000):
        psi = pow(g, (q - 1) // (2 * N), q)
        if pow(psi, N, q) == q - 1:
            return psi
    raise ValueError


def tables(N, q=Q0):
    logN = N.bit_length() - 1
    psi = find_psi(N, q); ipsi = pow(psi, q - 2, q)
    pr = [pow(psi, _bitrev(i, logN), q) for i in range(N)]
    ipr = [pow(ipsi, _bitrev(i, logN), q) for i in range(N)]
    return pr, ipr


def ntt(a, pr, q=Q0):
    a = list(a); N = len(a); t = N; m = 1
    while m < N:
        t //= 2
        for i in range(m):
            j1 = 2 * i * t; S = pr[m + i]
            for j in range(j1, j1 + t):
                U = a[j]; V = a[j + t] * S % q
                a[j] = (U + V) % q; a[j + t] = (U - V) % q
        m *= 2
    return a


def intt(a, ipr, q=Q0):
    a = list(a); N = len(a); t = 1; m = N
    while m > 1:
        j1 = 0; h = m // 2
        for i in range(h):
            S = ipr[h + i]
            for j in range(j1, j1 + t):
                U = a[j]; V = a[j + t]
                a[j] = (U + V) % q; a[j + t] = (U - V) * S % q
            j1 += 2 * t
        t *= 2; m //= 2
    ninv = pow(N, q - 2, q)
    return [x * ninv % q for x in a]


def negacyclic_mul(a, b, q=Q0):
    N = len(a); r = [0] * N
    for i in range(N):
        if a[i] == 0: continue
        for j in range(N):
            k = i + j
            if k < N: r[k] = (r[k] + a[i] * b[j]) % q
            else: r[k - N] = (r[k - N] - a[i] * b[j]) % q
    return r
