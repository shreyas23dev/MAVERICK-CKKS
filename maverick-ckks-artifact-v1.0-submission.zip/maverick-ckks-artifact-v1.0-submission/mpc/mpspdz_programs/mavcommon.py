# Shared MP-SPDZ helpers for MAVERICK-CKKS (imported by the .mpc programs at compile time).
import sys
sys.path.insert(0, 'Programs/Source')  # nttlib.py is installed next to this file
from nttlib import tables
from Compiler.types import sint, cint, Array
from Compiler.library import for_range, public_input, print_ln


def ntt_inplace(a, N, pr):
    """Negacyclic CT NTT on a secret sint.Array; linear (public twiddles), no communication."""
    t, m = N, 1
    while m < N:
        t //= 2
        for i in range(m):
            j1 = 2 * i * t
            S = cint(pr[m + i])
            U = a.get_vector(j1, t)
            V = a.get_vector(j1 + t, t) * S
            a.assign_vector(U + V, j1)
            a.assign_vector(U - V, j1 + t)
        m *= 2


def uniform_bits_vector(N, k):
    """Centred uniform integers in [-2^(k-1), 2^(k-1)) from k authenticated random bits each."""
    acc = sint.get_random_bit(size=N)
    for j in range(1, k):
        acc = acc + sint.get_random_bit(size=N) * cint(2 ** j)
    return acc - cint(2 ** (k - 1))


def read_public(N):
    arr = cint.Array(N)
    @for_range(N)
    def _(i):
        arr[i] = public_input()
    return arr


def print_open(tag, vec, N):
    out = cint.Array(N)
    out.assign_vector(vec)
    @for_range(N)
    def _(i):
        print_ln(tag + ' %s', out[i])
