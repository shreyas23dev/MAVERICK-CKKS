// Lattigo glue for the MP-SPDZ (MASCOT) MAVERICK-CKKS pipeline.
// Single-prime CKKS ring R_q0, q0 = MPC field. Files: one integer per line, coefficient domain.
package main

import (
	"bufio"
	"flag"
	"fmt"
	"math"
	"math/rand"
	"os"
	"strconv"

	"github.com/tuneinsight/lattigo/v6/core/rlwe"
	"github.com/tuneinsight/lattigo/v6/ring"
	"github.com/tuneinsight/lattigo/v6/schemes/ckks"
	"github.com/tuneinsight/lattigo/v6/utils/sampling"
)

func readPoly(path string, N int) []uint64 {
	f, err := os.Open(path)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	v := make([]uint64, 0, N)
	for sc.Scan() {
		x, err := strconv.ParseUint(sc.Text(), 10, 64)
		if err != nil {
			panic(err)
		}
		v = append(v, x)
	}
	if len(v) != N {
		panic(fmt.Sprintf("%s: got %d values", path, len(v)))
	}
	return v
}
func writePoly(path string, v []uint64) {
	f, _ := os.Create(path)
	w := bufio.NewWriter(f)
	for _, x := range v {
		fmt.Fprintln(w, x)
	}
	w.Flush()
	f.Close()
}

func params(logN int, q0 uint64, logScale int) ckks.Parameters {
	p, err := ckks.NewParametersFromLiteral(ckks.ParametersLiteral{LogN: logN, Q: []uint64{q0}, LogDefaultScale: logScale})
	if err != nil {
		panic(err)
	}
	return p
}

func toNTTMont(rq *ring.Ring, c []uint64) ring.Poly {
	p := rq.NewPoly()
	copy(p.Coeffs[0], c)
	rq.NTT(p, p)
	rq.MForm(p, p)
	return p
}

func main() {
	mode := flag.String("mode", "selftest", "selftest|encrypt|decode")
	logN := flag.Int("logN", 12, "")
	q0 := flag.Uint64("q0", 576460752303439873, "")
	logScale := flag.Int("logScale", 56, "")
	dir := flag.String("dir", ".", "")
	seed := flag.Int64("seed", 1, "")
	flag.Parse()
	prm := params(*logN, *q0, *logScale)
	rq := prm.RingQ()
	N := prm.N()
	ecd := ckks.NewEncoder(prm)
	switch *mode {
	case "selftest", "encrypt":
		var pk *rlwe.PublicKey
		var sk *rlwe.SecretKey
		if *mode == "selftest" { // build pk coefficients the way the MPC does, from a Go-side key
			kg := ckks.NewKeyGenerator(prm)
			sk = kg.GenSecretKeyNew()
			prng, _ := sampling.NewKeyedPRNG([]byte("crs"))
			a := rq.NewPoly()
			ring.NewUniformSampler(prng, rq).Read(a) // coefficient domain
			s := rq.NewPoly()
			rq.IMForm(sk.Value.Q, s)
			rq.INTT(s, s)
			e := rq.NewPoly()
			for j := 0; j < N; j++ {
				v := int64(rand.Intn(16)) - 8
				if v < 0 {
					e.Coeffs[0][j] = *q0 - uint64(-v)
				} else {
					e.Coeffs[0][j] = uint64(v)
				}
			}
			an, sn := rq.NewPoly(), rq.NewPoly()
			rq.NTT(a, an)
			rq.NTT(s, sn)
			pk0 := rq.NewPoly()
			rq.MulCoeffsBarrett(an, sn, pk0)
			rq.INTT(pk0, pk0)
			rq.Neg(pk0, pk0)
			rq.Add(pk0, e, pk0)
			writePoly(*dir+"/pk0.txt", pk0.Coeffs[0])
			writePoly(*dir+"/a.txt", a.Coeffs[0])
		}
		pk0 := readPoly(*dir+"/pk0.txt", N)
		a := readPoly(*dir+"/a.txt", N)
		pk = rlwe.NewPublicKey(prm)
		pk.Value[0].Q = toNTTMont(rq, pk0)
		pk.Value[1].Q = toNTTMont(rq, a)
		rng := rand.New(rand.NewSource(*seed))
		slots := prm.MaxSlots()
		m1, m2, want := make([]complex128, slots), make([]complex128, slots), make([]complex128, slots)
		for i := range m1 {
			m1[i] = complex(2*rng.Float64()-1, 2*rng.Float64()-1)
			m2[i] = complex(2*rng.Float64()-1, 2*rng.Float64()-1)
			want[i] = m1[i] + m2[i]
		}
		enc := ckks.NewEncryptor(prm, pk)
		pt := ckks.NewPlaintext(prm, 0)
		_ = ecd.Encode(m1, pt)
		c1, err := enc.EncryptNew(pt)
		if err != nil {
			panic(err)
		}
		_ = ecd.Encode(m2, pt)
		c2, _ := enc.EncryptNew(pt)
		ct, _ := ckks.NewEvaluator(prm, nil).AddNew(c1, c2)
		x0, x1 := rq.NewPoly(), rq.NewPoly()
		rq.INTT(ct.Value[0], x0)
		rq.INTT(ct.Value[1], x1)
		writePoly(*dir+"/c0.txt", x0.Coeffs[0])
		writePoly(*dir+"/c1.txt", x1.Coeffs[0])
		f, _ := os.Create(*dir + "/want.txt")
		for _, w := range want {
			fmt.Fprintf(f, "%.17g %.17g\n", real(w), imag(w))
		}
		f.Close()
		if *mode == "selftest" { // decrypt in Go to validate the format conversion
			got := make([]complex128, slots)
			_ = ecd.Decode(ckks.NewDecryptor(prm, sk).DecryptNew(ct), got)
			var sq float64
			for i := range got {
				d := real(got[i]) - real(want[i])
				sq += d * d
			}
			fmt.Printf("selftest log2RMSE %.3f\n", math.Log2(math.Sqrt(sq/float64(slots))))
		}
	case "decode":
		z := readPoly(*dir+"/z.txt", N)
		pt := ckks.NewPlaintext(prm, 0)
		copy(pt.Value.Coeffs[0], z)
		rq.NTT(pt.Value, pt.Value)
		got := make([]complex128, prm.MaxSlots())
		_ = ecd.Decode(pt, got)
		f, _ := os.Open(*dir + "/want.txt")
		sc := bufio.NewScanner(f)
		var sq, mx float64
		i := 0
		for sc.Scan() {
			var re, im float64
			fmt.Sscanf(sc.Text(), "%g %g", &re, &im)
			d := real(got[i]) - re
			sq += d * d
			if math.Abs(d) > mx {
				mx = math.Abs(d)
			}
			i++
		}
		fmt.Printf("{\"slots\":%d,\"log2RMSE\":%.4f,\"maxErr\":%.6g}\n", i, math.Log2(math.Sqrt(sq/float64(i))), mx)
	}
}
