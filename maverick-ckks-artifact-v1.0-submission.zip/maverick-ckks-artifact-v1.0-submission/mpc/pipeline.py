"""End-to-end MAVERICK-CKKS run: MASCOT (MP-SPDZ, separate party processes over TCP) for key
generation and verified threshold decryption; Lattigo for encryption/evaluation/decoding.
Usage: pipeline.py <n_parties> <k_list comma> <tag> [--skip-keygen]"""
import os, re, subprocess, sys, json, time, random, math

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
MP = os.environ.get('MPSPDZ_DIR', os.path.join(ROOT, '..', 'third_party', 'mp-spdz-0.4.0'))
RUNS = os.environ.get('MAV_RUNS', os.path.join(ROOT, '..', 'results', 'mascot_runs'))
GLUE = os.path.join(ROOT, 'glue', 'glue')
from nttlib import Q0, tables, ntt, intt
N = 4096; LOGSCALE = 56
n = int(sys.argv[1]); ks = [int(x) for x in sys.argv[2].split(',')]; tag = sys.argv[3]
skip_keygen = '--skip-keygen' in sys.argv
W = os.path.join(RUNS, tag); os.makedirs(W, exist_ok=True)
LOG = open(f'{W}/log.jsonl', 'a')
pr, ipr = tables(N)

def log(rec):
    rec['tag'] = tag; rec['n'] = n; rec['time_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    LOG.write(json.dumps(rec) + '\n'); LOG.flush(); print(json.dumps(rec), flush=True)

def wpub(prog, vals):
    with open(f'{MP}/Programs/Public-Input/{prog}', 'w') as f:
        f.write('\n'.join(str(v) for v in vals) + '\n')

def mascot(prog):
    t0 = time.time()
    r = subprocess.run(['Scripts/mascot.sh', '-N', str(n), '-P', str(Q0), prog], cwd=MP, capture_output=True, text=True)
    wall = time.time() - t0
    out = r.stdout + r.stderr
    open(f'{W}/{prog}.out', 'w').write(out)
    m = re.search(r'Time = ([\d.]+) seconds', out); d = re.search(r'Global data sent = ([\d.]+) MB', out)
    return out, dict(prog=prog, rc=r.returncode, wall_s=wall, mpc_time_s=float(m.group(1)) if m else None,
                     global_MB=float(d.group(1)) if d else None, mac_fail=('MAC check failed' in out or 'MacCheck' in out))

def readvals(out, tagname):
    v = [int(x) % Q0 for x in re.findall(rf'^{tagname} (-?\d+)$', out, re.M)]
    assert len(v) == N, (tagname, len(v))
    return v

os.makedirs(f'{MP}/Programs/Public-Input', exist_ok=True)
if not skip_keygen:
    for f in os.listdir(f'{MP}/Persistence') if os.path.isdir(f'{MP}/Persistence') else []:
        os.remove(f'{MP}/Persistence/{f}')
    rnd = random.Random(f'crs-{tag}')
    a = [rnd.randrange(Q0) for _ in range(N)]
    wpub(f'keygen-{N}', ntt(a, pr))
    out, info = mascot(f'keygen-{N}')
    pk0 = intt(readvals(out, 'PK'), ipr)
    open(f'{W}/pk0.txt', 'w').write('\n'.join(map(str, pk0)) + '\n')
    open(f'{W}/a.txt', 'w').write('\n'.join(map(str, a)) + '\n')
    info['stage'] = 'keygen'; info['random_bits'] = 6 * N; log(info)

for k in ks:
    seed = random.randrange(1 << 30)
    subprocess.run([GLUE, '-mode', 'encrypt', '-dir', W, '-logScale', str(LOGSCALE), '-seed', str(seed)], check=True)
    c0 = [int(x) for x in open(f'{W}/c0.txt')]; c1 = [int(x) for x in open(f'{W}/c1.txt')]
    wpub(f'decrypt-{N}-{k}', ntt(c0, pr) + ntt(c1, pr))
    out, info = mascot(f'decrypt-{N}-{k}')
    z = intt(readvals(out, 'Z'), ipr)
    open(f'{W}/z.txt', 'w').write('\n'.join(map(str, z)) + '\n')
    dec = json.loads(subprocess.run([GLUE, '-mode', 'decode', '-dir', W, '-logScale', str(LOGSCALE)], capture_output=True, text=True, check=True).stdout)
    pred_sm = (k - math.log2(math.sqrt(12))) + (math.log2(N) - 1) / 2 - LOGSCALE
    info.update(stage='decrypt', k=k, random_bits=k * N, logScale=LOGSCALE, pred_log2RMSE_smudge_only=pred_sm, **dec)
    log(info)
