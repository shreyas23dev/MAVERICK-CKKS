"""MAVERICK-CKKS Python experiments (authentication, abort, conversion, Rev.9 statistics).
All results written to data/py_results.json. Seeded for reproducibility."""
import json, math, sys
import numpy as np
from scipy import stats

OUT = sys.argv[1]
rng = np.random.default_rng(20261115)
R = {}

# ---------- E1: SPDZ-style information-theoretic MAC check (no privileged oracle) ----------
def mac_trials(p, n, trials, tamper=True):
    """Vectorised for p < 2^31; values, MAC key and shares are uniform in F_p."""
    p = np.int64(p)
    x = rng.integers(0, p, trials)
    alpha_sh = rng.integers(0, p, (n, trials)); alpha = alpha_sh.sum(0) % p
    x_sh = rng.integers(0, p, (n, trials)); x_sh[-1] = (x - x_sh[:-1].sum(0)) % p
    m = (alpha * x) % p
    m_sh = rng.integers(0, p, (n, trials)); m_sh[-1] = (m - m_sh[:-1].sum(0)) % p
    if tamper:  # corrupt P1 adds Delta != 0 to value share and Delta' = g*Delta to MAC share, g a guess of alpha
        D = rng.integers(1, p, trials); g = rng.integers(0, p, trials)
        x_sh[0] = (x_sh[0] + D) % p; m_sh[0] = (m_sh[0] + g * D) % p
    xo = x_sh.sum(0) % p                       # opened (possibly wrong) value
    sig = (m_sh - alpha_sh * xo) % p           # each party's check share
    accept = (sig.sum(0) % p) == 0
    return accept, x

def mac_big(p, n, trials):
    acc = 0
    r = np.random.default_rng(7)
    for _ in range(trials):
        rnd = lambda: int(r.integers(0, 2**62)) % p
        x = rnd(); a_sh = [rnd() for _ in range(n)]; a = sum(a_sh) % p
        xs = [rnd() for _ in range(n - 1)]; xs.append((x - sum(xs)) % p)
        ms = [rnd() for _ in range(n - 1)]; ms.append((a * x - sum(ms)) % p)
        D = rnd() or 1; g = rnd()
        xs[0] = (xs[0] + D) % p; ms[0] = (ms[0] + g * D) % p
        xo = sum(xs) % p
        acc += (sum((ms[i] - a_sh[i] * xo) for i in range(n)) % p) == 0
    return acc

mac = []
for p in [3, 7, 31, 127, 251, 8191, 65521, 2**31 - 1]:
    T = 400000
    acc, _ = mac_trials(p, 3, T)
    k = int(acc.sum()); lo, hi = stats.beta.ppf([0.025, 0.975], [k, k + 1], [T - k + 1, T - k]) if k > 0 else (0.0, 3.689 / T)
    mac.append(dict(p=p, log2p=math.log2(p), trials=T, forged=k, rate=k / T, predicted=1 / p, ci_lo=float(np.nan_to_num(lo)), ci_hi=float(hi)))
    acc0, _ = mac_trials(p, 3, 20000, tamper=False)
    mac[-1]['honest_accept'] = float(acc0.mean())
T = 20000; k = mac_big(2**61 - 1, 3, T)
mac.append(dict(p=2**61 - 1, log2p=61.0, trials=T, forged=k, rate=k / T, predicted=2.0**-61, ci_lo=0.0, ci_hi=3.689 / T, honest_accept=1.0))
R['mac'] = mac

# abort independence: is MAC acceptance correlated with the sign of the shared noise value?
p = 251; Tn = 400000
acc, x = mac_trials(p, 3, Tn)
k8 = 8; e = (x % 256) - 128  # centred 8-bit noise embedded in F_p (x uniform on F_p -> use first 256 values)
sel = x < 256
e = e[sel]; a = acc[sel]
R['mac_abort_independence'] = dict(p=p, samples=int(sel.sum()), accept_rate_neg=float(a[e < 0].mean()), accept_rate_nonneg=float(a[e >= 0].mean()),
                                    chi2_p=float(stats.chi2_contingency([[a[e < 0].sum(), (~a[e < 0]).sum()], [a[e >= 0].sum(), (~a[e >= 0]).sum()]])[1]))

# ---------- E2: selective abort, exact total-variation computations ----------
def tv(pmf1, pmf2):
    return 0.5 * np.abs(pmf1 - pmf2).sum()

def cond_pmf(support, mask):
    p = mask.astype(float); return p / p.sum()

abort = []
for k in [8, 12, 16, 20]:
    W = 2**k; xs = np.arange(-W // 2, W // 2)
    pad = 64
    full = np.arange(-W // 2 - pad, W // 2 + pad)
    def embed(mask):
        v = np.zeros(full.size); v[pad:pad + W] = mask.astype(float); return v / v.sum()
    preds = {
        'none': np.ones(W, bool),
        'value-independent coin (p=1/2)': None,
        'sign (e>=0)': xs >= 0,
        'threshold (e<-W/4), p=1/4': xs < -W // 4,
        'parity (e even)': xs % 2 == 0,
        'residue mod 4 = 0': xs % 4 == 0,
    }
    base = embed(np.ones(W, bool))
    for name, m in preds.items():
        if m is None:  # independent abort: conditional law equals prior
            pa = 0.5; c = base
        else:
            pa = m.mean(); c = embed(m)
        sh = {}
        for d in [1, 2, 4, 16]:
            sh[d] = tv(c, np.roll(c, d))
        runs = None if m is None else int(np.sum(np.diff(np.concatenate([[0], m.astype(int), [0]])) == 1))
        bound = {d: (min(1.0, runs * d / (pa * W)) if runs else min(1.0, d / W)) for d in sh}
        abort.append(dict(k=k, predicate=name, accept_prob=float(pa), tv_to_prior=float(tv(c, base)), runs=runs,
                          shift_tv={str(d): float(v) for d, v in sh.items()}, shift_bound={str(d): float(v) for d, v in bound.items()}))
R['abort'] = abort

# Monte-Carlo replay of Rev.9 sign filter vs MAC-protected abort (k=8, 120 and 10^5 trials)
k = 8; W = 256
e_mc = rng.integers(-128, 128, 100000)
R['abort_mc'] = dict(trials=100000, sign_accept=float((e_mc >= 0).mean()), sign_tv_empirical=float(
    tv(np.bincount(e_mc[e_mc >= 0] + 128, minlength=W) / (e_mc >= 0).sum(), np.bincount(e_mc + 128, minlength=W) / e_mc.size)))

# ---------- E3: authenticated field-to-ring conversion by masked opening ----------
# open c = e + 2^{k-1} + r over F_p with r uniform on [0,2^{k+s}); ring shares mod q: e = c - 2^{k-1} - r (mod q)
q = 0x7fffffffe0001  # a 51-bit NTT-friendly prime is not required here; any odd modulus works for the check
q = 1152921504606830593  # 60-bit NTT-friendly prime (Lattigo-style, q = 1 mod 2N)
conv = []
for kbits in [8, 20, 30]:
    for s in [0, 1, 2, 4, 8, 16, 24, 32, 40]:
        # exact worst-case leakage: TV(c|e, c|e') = |e-e'|/2^{k+s}, max over e,e' in range = (2^k - 1)/2^{k+s}
        tv_exact = min(1.0, (2**kbits - 1) / 2**(kbits + s))
        conv.append(dict(k=kbits, s=s, tv_worst=tv_exact, bound=2.0**-s))
# Monte-Carlo correctness with n = 3 parties, p = 2^61-1, k = 20, s = 40
def convert(kbits, s, p, n, trials, r_gen):
    bad = 0
    for _ in range(trials):
        e = int(r_gen.integers(-2**(kbits - 1), 2**(kbits - 1)))
        r = int(r_gen.integers(0, 2**62)) % (2**(kbits + s))
        # shares of r in both domains (daBit/edaBit-style preprocessing, emulated)
        rp = [int(r_gen.integers(0, 2**62)) % p for _ in range(n - 1)]; rp.append((r - sum(rp)) % p)
        rq = [int(r_gen.integers(0, 2**62)) % q for _ in range(n - 1)]; rq.append((r - sum(rq)) % q)
        ep = [int(r_gen.integers(0, 2**62)) % p for _ in range(n - 1)]; ep.append((e - sum(ep)) % p)
        c = (sum(ep) + 2**(kbits - 1) + sum(rp)) % p          # opened value
        out = [(-rq[i]) % q for i in range(n)]; out[0] = (out[0] + c - 2**(kbits - 1)) % q
        got = sum(out) % q
        bad += got != (e % q)
    return bad
rg = np.random.default_rng(11)
R['conversion'] = dict(leakage=conv,
                       correct_large_p=dict(k=20, s=40, p='2^61-1', trials=50000, failures=convert(20, 40, 2**61 - 1, 3, 50000, rg)),
                       wrap_ablation=dict(k=20, s=40, p='2^59-55 (< 2^{k+s+1})', trials=50000, failures=convert(20, 40, 2**59 - 55, 3, 50000, rg)))

# ---------- E4: statistical model of the recorded Revision 9 observations ----------
M, Tn = 256, 120
ED = M * (1 - (1 - 1 / M)**Tn)
VD = M * (M - 1) * (1 - 2 / M)**Tn + M * (1 - 1 / M)**Tn - (M * (1 - 1 / M)**Tn)**2
sims = np.array([np.unique(rng.integers(0, M, Tn)).size for _ in range(100000)])
acc = 59
ci = stats.binomtest(acc, Tn, 0.5).proportion_ci(method='exact')
R['rev9'] = dict(expected_distinct=ED, sd_distinct=math.sqrt(VD), sim_mean=float(sims.mean()), sim_sd=float(sims.std()),
                 pct_le_96=float((sims <= 96).mean()), sim_q025=float(np.quantile(sims, .025)), sim_q975=float(np.quantile(sims, .975)),
                 accept=acc, trials=Tn, accept_ci=[ci.low, ci.high], binom_p=stats.binomtest(acc, Tn, 0.5).pvalue,
                 hist=np.bincount(sims, minlength=M + 1)[80:112].tolist())

# ---------- E5: smudging distance, uniform vs discrete Gaussian (exact sums) ----------
sm = []
for logs in [4, 6, 8, 10, 12]:
    sigma = 2.0**logs
    x = np.arange(-int(12 * sigma), int(12 * sigma) + 1)
    g = np.exp(-x**2 / (2 * sigma**2)); g /= g.sum()
    Wu = sigma * math.sqrt(12)
    for d in [1, 4, 16]:
        tvg = tv(g, np.roll(g, d))
        sm.append(dict(log2sigma=logs, delta=d, tv_gauss=float(tvg), tv_unif=min(1.0, d / Wu), gauss_approx=d / (sigma * math.sqrt(2 * math.pi))))
R['smudge'] = sm

json.dump(R, open(OUT, 'w'), indent=1, default=float)
print(json.dumps({k: (v if k in ('rev9', 'mac_abort_independence', 'abort_mc') else '...') for k, v in R.items()}, indent=1, default=float))
for m in mac: print(m['p'], m['forged'], '%.3e' % m['rate'], '%.3e' % m['predicted'], m['honest_accept'])
print(R['conversion']['correct_large_p'], R['conversion']['wrap_ablation'])
for a in abort:
    if a['k'] == 16: print(a['predicate'], a['accept_prob'], round(a['tv_to_prior'], 4), a['shift_tv'], a['shift_bound'])
