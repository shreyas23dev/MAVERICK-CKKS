"""A7 ablation: masked reduction with a field below the size requirement (arithmetic emulation)."""
import json, math, random, sys
q = 576460752303439873; X = 2**73; T = (2 * X) // q + 2; LT = math.ceil(math.log2(T)); sigma = 40
rng = random.Random(5)
def trial(p, M=20000):
    bad = 0
    for _ in range(M):
        x = rng.randrange(-X, X); R = rng.randrange(2**(LT + sigma)); y = (x + q * (X // q + 1) + q * R) % p
        bad += (y % q) != (x % q)
    return bad
r = dict(T=T, LT=LT, req_log2p=math.log2(2 * X + q * 2**(LT + sigma) * 1.0), big=trial(170141183460469231731687303715885907969), small=trial(2**113 - 1), M=20000)
json.dump(r, open(sys.argv[1], 'w')); print(r)
