"""Fits empirical models and draws all manuscript figures from data/*.jsonl and data/py_results.json."""
import json, math, sys, collections
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

D = sys.argv[1]; FIG = sys.argv[2]
C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']  # validated categorical slots 1-4, fixed order
INK, INK2, GRID = '#0b0b0b', '#52514e', '#e4e3df'
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2, 'ytick.color': INK2,
                     'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': .6, 'axes.spines.top': False, 'axes.spines.right': False,
                     'lines.linewidth': 2, 'legend.frameon': False, 'figure.dpi': 200, 'savefig.bbox': 'tight', 'font.family': 'serif'})
MK = ['o', 's', '^', 'D']

def load(f): return [json.loads(l) for l in open(f'{D}/{f}')]
P = load('precision.jsonl'); T = load('timing.jsonl'); A = load('attack.jsonl'); R = json.load(open(f'{D}/py_results.json'))
S = {}

# ---- empirical precision model: log2 RMSE = a*log2(sigma_tot) + b*logN + c ----
g = collections.defaultdict(list)
for r in P: g[(r['logN'], r['n'], r['mode'], r['logSigma'])].append(r['rmse'])
rows = []
sct = {}  # ciphertext noise std per (logN, n), from the no-smudging runs: RMSE = sigma_ct*sqrt(N/2)/Delta
for (logN, n, mode, ls), v in g.items():
    if mode == 'none': sct[(logN, n)] = np.mean(v) * 2**40 / math.sqrt(2**logN / 2)
S['sigma_ct_log2'] = {f'{k[0]}_{k[1]}': math.log2(v) for k, v in sct.items()}
for (logN, n, mode, ls), v in g.items():
    if mode == 'none': continue
    var_sm = (n if mode == 'independent' else 1) * 4.0**ls
    tot = 0.5 * math.log2(var_sm + sct[(logN, n)]**2)
    rows.append((tot, logN, math.log2(np.mean(v)), mode, n, ls))
X = np.array([[r[0], r[1], 1] for r in rows]); y = np.array([r[2] for r in rows])
coef, res, *_ = np.linalg.lstsq(X, y, rcond=None)
pred = X @ coef; ss = ((y - y.mean())**2).sum(); r2 = 1 - ((y - pred)**2).sum() / ss
theory = np.array([[r[0], r[1]] for r in rows]) @ np.array([1, .5]) - 40.5
S['precision_fit'] = dict(a=coef[0], b=coef[1], c=coef[2], r2=r2, npts=len(rows), max_abs_resid_theory=float(np.abs(y - theory).max()),
                          mean_abs_resid_theory=float(np.abs(y - theory).mean()))
# precision gap independent vs collaborative at equal per-party sigma
gap = collections.defaultdict(list)
for (logN, n, mode, ls), v in g.items():
    if mode == 'independent':
        if ls >= 20: gap[(logN, n)].append(math.log2(np.mean(v)) - math.log2(np.mean(g[(logN, n, 'collab-gauss', ls)])))
S['gap'] = {f'{k[0]}_{k[1]}': float(np.mean(v)) for k, v in sorted(gap.items())}
S['none_rmse'] = {f'{k[0]}_{k[1]}': float(np.mean(v)) for k, v in g.items() if k[2] == 'none'}
S['uniform_vs_gauss_diff'] = float(np.mean([abs(math.log2(np.mean(g[(a, b, 'collab-unif', c)])) - math.log2(np.mean(g[(a, b, 'collab-gauss', c)])))
                                            for (a, b, m, c) in g if m == 'collab-unif']))

# Fig 1: precision vs sigma (logN = 14)
fig, ax = plt.subplots(figsize=(5.6, 3.4))
xs = [10, 15, 20, 25, 30]
for i, (mode, n, lab) in enumerate([('collab-gauss', 16, 'Collaborative, $n=16$'), ('independent', 2, 'Independent, $n=2$'),
                                     ('independent', 16, 'Independent, $n=16$'), ('collab-unif', 2, 'Collaborative uniform, $n=2$')]):
    ys = [math.log2(np.mean(g[(14, n, mode, s)])) for s in xs]
    ax.plot(xs, ys, marker=MK[i], ms=6, color=C[i], label=lab, lw=1.6 if i != 3 else 0, mec='#fcfcfb', mew=1)
xx = np.linspace(9, 31, 2)
ax.plot(xx, xx + 6.5 - 40.5, ls='--', lw=1, color=INK2, label='Model (7), $\\sigma_{tot}=\\sigma$')
ax.plot(xx, xx + 2 + 6.5 - 40.5, ls=':', lw=1, color=INK2, label='Model (7), $\\sigma_{tot}=4\\sigma$')
ax.set_xlabel('$\\log_2$ per-party smudging std. dev. $\\sigma$'); ax.set_ylabel('$\\log_2$ slot RMSE')
ax.set_title('Decryption error, Lattigo threshold CKKS, $N=2^{14}$, $\\Delta=2^{40}$', fontsize=9, color=INK, loc='left')
ax.legend(fontsize=7.5, loc='upper left'); fig.savefig(f'{FIG}/fig01_precision.png'); plt.close(fig)

# Fig 2: precision gap vs n
fig, ax = plt.subplots(figsize=(5.0, 3.0))
ns = [2, 4, 8, 16]
for i, logN in enumerate([12, 13, 14]):
    ax.plot(ns, [S['gap'][f'{logN}_{n}'] for n in ns], marker=MK[i], ms=6, lw=0, color=C[i], label=f'$N=2^{{{logN}}}$')
nn = np.linspace(2, 16, 50); ax.plot(nn, .5 * np.log2(nn), color=INK2, lw=1, ls='--', label='model $\\frac{1}{2}\\log_2 n$')
ax.set_xscale('log', base=2); ax.set_xticks(ns); ax.set_xticklabels(ns)
ax.set_xlabel('Number of parties $n$'); ax.set_ylabel('Precision lost (bits)')
ax.set_title('Independent minus collaborative smudging, equal per-party $\\sigma$', fontsize=9, loc='left')
ax.legend(fontsize=7.5); fig.savefig(f'{FIG}/fig02_gap.png'); plt.close(fig)

# ---- timing model ----
tm = [r for r in T if r['exp'] == 'timing']; ck = [r for r in T if r['exp'] == 'ckg']
lv = {r['logN']: r['levels'] for r in ck}
for mode in ['none', 'independent', 'collab-unif']:
    pts = [(math.log2(2**r['logN'] * lv[r['logN']]), math.log2(r['genMedMs'])) for r in tm if r['mode'] == mode and r['n'] >= 4]
    a, b = np.polyfit(*zip(*pts), 1); S[f'time_slope_{mode}'] = dict(slope=a, intercept=b)
S['timing'] = {f"{r['logN']}_{r['n']}_{r['mode']}": dict(gen=r['genMedMs'], agg=r['aggMedMs'], bytes=r['shareBytes'],
               gen_q=list(np.quantile(r['gen'], [.25, .75])), agg_q=list(np.quantile(r['agg'], [.25, .75]))) for r in tm}
S['ckg'] = {f"{r['logN']}_{r['n']}": dict(ms=r['ms'], bytes=r['shareBytes'], levels=r['levels'], logQP=r['logQP']) for r in ck}
# aggregation linear in n
for logN in [14, 15]:
    pts = [(r['n'], r['aggMedMs']) for r in tm if r['mode'] == 'collab-unif' and r['logN'] == logN]
    a, b = np.polyfit(*zip(*pts), 1); S[f'agg_lin_{logN}'] = dict(per_party_ms=a, const=b)

fig, ax = plt.subplots(figsize=(5.2, 3.1))
logNs = [12, 13, 14, 15]
for i, (mode, lab) in enumerate([('none', 'No smudging'), ('independent', 'Independent Gaussian (Lattigo KeySwitch)'), ('collab-unif', 'Collaborative, shares pre-sampled')]):
    med = [S['timing'][f'{l}_4_{mode}']['gen'] for l in logNs]
    q = np.array([S['timing'][f'{l}_4_{mode}']['gen_q'] for l in logNs])
    ax.errorbar(logNs, med, yerr=[np.array(med) - q[:, 0], q[:, 1] - np.array(med)], marker=MK[i], ms=6, color=C[i], label=lab, capsize=2, lw=1.6, mec='#fcfcfb')
ax.set_yscale('log'); ax.set_xticks(logNs); ax.set_xticklabels([f'$2^{{{l}}}$' for l in logNs])
ax.set_xlabel('Ring degree $N$ (with $L$ = 2, 4, 7, 14 RNS limbs)'); ax.set_ylabel('Share generation, ms (median, IQR)')
ax.set_title('Per-party decryption-share cost, $n=4$, 15 repetitions', fontsize=9, loc='left')
ax.legend(fontsize=7.5); fig.savefig(f'{FIG}/fig03_timing.png'); plt.close(fig)

# Fig 4: MAC forgery
m = [x for x in R['mac'] if x['forged'] > 0]
fig, ax = plt.subplots(figsize=(5.0, 3.0))
lp = np.array([x['log2p'] for x in m]); rate = np.array([x['rate'] for x in m])
lo = np.array([x['ci_lo'] for x in m]); hi = np.array([x['ci_hi'] for x in m])
ax.errorbar(lp, rate, yerr=[rate - lo, hi - rate], fmt='o', color=C[0], ms=6, capsize=2, label='Observed forgery rate (95% CI)', mec='#fcfcfb')
xx = np.linspace(1.3, 32, 50); ax.plot(xx, 2**-xx, color=INK2, ls='--', lw=1, label='Model $1/p$')
z = [x for x in R['mac'] if x['forged'] == 0]
ax.scatter([x['log2p'] for x in z], [x['ci_hi'] for x in z], marker='v', color=C[1], s=36, label='Zero forgeries (upper 95% bound)', zorder=3)
ax.set_yscale('log'); ax.set_xlabel('$\\log_2 p$ (MAC field size)'); ax.set_ylabel('Accepted tampered openings')
ax.set_title('Information-theoretic MAC check, $n=3$, $4\\times10^5$ trials per field', fontsize=9, loc='left')
ax.legend(fontsize=7.5, loc='upper right'); fig.savefig(f'{FIG}/fig04_mac.png'); plt.close(fig)

# Fig 5: selective abort smudging distance
ab = [x for x in R['abort'] if x['k'] == 16]
fig, ax = plt.subplots(figsize=(5.6, 2.9))
labels = [x['predicate'] for x in ab]; v1 = [x['shift_tv']['1'] for x in ab]; v4 = [x['shift_tv']['4'] for x in ab]
yy = np.arange(len(ab))
ax.barh(yy + .2, v1, height=.38, color=C[0], label='shift $\\delta=1$')
ax.barh(yy - .2, v4, height=.38, color=C[1], label='shift $\\delta=4$')
ax.set_yticks(yy); ax.set_yticklabels(labels, fontsize=7.5); ax.set_xscale('log'); ax.invert_yaxis()
ax.set_xlabel('Smudging distance $\\mathrm{TV}(e+\\delta, e \\mid \\mathrm{accept})$')
ax.set_title('Exact smudging loss under abort predicates, $k=16$', fontsize=9, loc='left')
ax.legend(fontsize=7.5, loc='lower right'); fig.savefig(f'{FIG}/fig05_abort.png'); plt.close(fig)

# Fig 6: conversion leakage
cv = [x for x in R['conversion']['leakage'] if x['k'] == 20]
fig, ax = plt.subplots(figsize=(5.0, 2.9))
ax.plot([x['s'] for x in cv], [x['tv_worst'] for x in cv], marker='o', color=C[0], ms=6, label='Exact worst-case leakage', mec='#fcfcfb')
ax.plot([x['s'] for x in cv], [x['bound'] for x in cv], ls='--', color=INK2, lw=1, label='Bound $2^{-s}$')
ax.set_yscale('log', base=2); ax.set_xlabel('Statistical masking parameter $s$'); ax.set_ylabel('TV of opened value')
ax.set_title('Masked field-to-ring conversion, $k=20$', fontsize=9, loc='left'); ax.legend(fontsize=7.5)
fig.savefig(f'{FIG}/fig06_conversion.png'); plt.close(fig)

# Fig 7: Rev.9 distinct-value model
h = R['rev9']['hist']; xs = np.arange(80, 112)
fig, ax = plt.subplots(figsize=(5.0, 2.8))
ax.bar(xs, np.array(h) / sum(h), color=C[0], width=.8)
ax.axvline(96, color=C[1], lw=2); ax.text(103, max(h) / sum(h) * .8, 'recorded value: 96\n(56th percentile)', color=INK, fontsize=8)
ax.set_xlabel('Distinct values in 120 draws from 256'); ax.set_ylabel('Probability')
ax.set_title('Revision 9 diversity versus the uniform-sampling model ($10^5$ simulations)', fontsize=9, loc='left')
fig.savefig(f'{FIG}/fig07_rev9.png'); plt.close(fig)

S['attack'] = A; S['py'] = {k: R[k] for k in ['mac_abort_independence', 'abort_mc', 'conversion']}
S['rev9'] = {k: v for k, v in R['rev9'].items() if k != 'hist'}
json.dump(S, open(f'{D}/summary.json', 'w'), indent=1, default=float)
print(json.dumps({k: S[k] for k in ['precision_fit', 'gap', 'uniform_vs_gauss_diff', 'time_slope_none', 'time_slope_independent', 'time_slope_collab-unif', 'agg_lin_14', 'agg_lin_15']}, indent=1, default=float))
