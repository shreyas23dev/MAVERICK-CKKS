# MAVERICK-CKKS — research artifact (v1.0-submission)

Code, raw data and results for *"MAVERICK-CKKS: Malicious-Secure Collaborative Sampling and Verified Threshold Decryption for Approximate Secure Computation"* (submitted to the Journal of Information Security and Applications).

## Contents
| Path | What it is |
|---|---|
| `mpc/mpspdz_programs/` | MP-SPDZ programs: `keygen.mpc` (key generation inside MASCOT), `decrypt.mpc` (decryption with jointly sampled noise), `verify.mpc` (integrity probe for tampering tests), `modred.mpc` (multi-limb masked reduction), `mavcommon.py` / `nttlib.py` (in-MPC negacyclic NTT) |
| `mpc/glue/` | Lattigo v6.1.1 glue: imports the MPC public key, encrypts and evaluates, decodes |
| `mpc/pipeline.py`, `mpc/tamper.py`, `mpc/modred_run.py` | Orchestration of E10, E11 and E12 |
| `lattigo_harness/` | Experiments E1–E4 (precision sweep, timing, key-recovery attack, precision budget) |
| `python_experiments/` | E5–E9 (MAC emulation, abort TV, conversion leakage, smudging, Rev. 9 statistics), A7, model fits and figures |
| `figures_and_tables/` | MASCOT figures, CSV export, supplementary report and manuscript tables |
| `data/frozen/` | **Frozen raw outputs used in the paper** (JSON-lines, MASCOT logs) |
| `results_csv/`, `figures/` | Processed results (13 CSVs) and the 11 figures |
| `scripts/` | `build_go.sh`, `setup_mpspdz.sh`, `reproduce_quick.sh`, `reproduce_full.sh`, `check_quick.py` |
| `docs/` | Supplementary experiments report (PDF) and the clean-room reproduction log |
| `VERIFICATION.md` | Clean-room reproduction record |

## Requirements
Linux x86-64, Go ≥ 1.22, Python ≥ 3.10 (`pip install -r requirements.txt`), curl and openssl. MP-SPDZ v0.4.0 is downloaded by `scripts/setup_mpspdz.sh` (official static binaries).

## Reproduce
```bash
scripts/reproduce_quick.sh   # ~20 min on 2 vCPU: MASCOT keygen+decrypt, tampering, key recovery, Python; checks against data/frozen
scripts/reproduce_full.sh    # every experiment in the paper; several hours (MASCOT randomness generation dominates)
```
If `proxy.golang.org` is unreachable, set `GOPROXY=direct GOSUMDB=off`; the `replace` lines in each `go.mod` point to GitHub mirrors.
Environment variables: `MPSPDZ_DIR` (default `third_party/mp-spdz-0.4.0`) and `MAV_RUNS` (default `results/mascot_runs`).

## Experiment → command → output
| ID | Command | Output |
|---|---|---|
| E1 | `lattigo_harness/mav -exp precision -reps 5` | `precision.jsonl` → `E01_*.csv`, fig01–02 |
| E2 | `mav -exp timing -reps 15` | `timing.jsonl` → `E02*.csv`, fig03 |
| E3 | `mav -exp attack -reps 20` | `attack.jsonl` → `E03_*.csv` |
| E4 | `mav -exp feasible -reps 10` | `feasible.jsonl` → `E04_*.csv` |
| E5–E9 | `python_experiments/py_experiments.py out.json` | `py_results.json` → `E05`–`E09`, fig04–07 |
| E10 | `mpc/pipeline.py <n> <k,...> <tag>` | `mascot_runs/<tag>/log.jsonl` → `E10_*.csv`, fig08, 09, 11 |
| E11 | `mpc/tamper.py <n> 10 <tag>` | `tamper.json` → `E11_*.csv`, fig10 |
| E12 | `mpc/modred_run.py 256` | `modred.json` → `E12_*.csv` |

## Scope
Executed on a single 2-vCPU host (all parties local, TLS/TCP over loopback). Data owners are assumed honest. λ = 40 needs a multi-limb decryption modulus and was not executed end to end. See the paper, Sections 11–12.

## Citation and licence
See `CITATION.cff` and `LICENSE`. MP-SPDZ and Lattigo are third-party software under their own licences and are not redistributed here.
