# Clean-room reproduction record

- **Date:** 2026-11-22 (UTC 16:50–17:10)
- **Host:** 2-vCPU Intel Xeon @ 2.30 GHz, 7 GB RAM, Linux; Go 1.24.7, Python 3.13
- **Procedure:** fresh copy of this artifact into an empty directory; MP-SPDZ v0.4.0 downloaded and the programs compiled from scratch; `scripts/reproduce_quick.sh` (full log in `docs/cleanroom_quick.log`)

| Check | Result |
|---|---|
| E10 MASCOT keygen + decrypt (n=2, k=4) | PASS: log2 RMSE −41.924 vs frozen −41.884 (fresh encryption randomness; tolerance 0.1) |
| E11 MASCOT tampering (n=2, 2 runs per variant) | PASS: controls 2/2 accepted; attacks 6/6 rejected with `MacCheck Failure` |
| E3 key recovery (3 trials) | PASS: 3/3 recoveries without smudging; 0 with smudging |
| E5–E9 Python experiments | PASS: byte-identical to the frozen JSON (seeded) |
| Figures, 13 CSVs and manuscript tables regenerated from `data/frozen/` | identical CSVs; LaTeX tables byte-identical to the manuscript |

Overall: ALL CHECKS PASSED (exit code 0).
