"""Builds Supplementary_Experiments_Report.tex from the CSV results (all numbers are read, none typed)."""
import csv, json, math, statistics as st, sys, collections
C = sys.argv[1]; OUT = sys.argv[2]
def rd(n): return list(csv.DictReader(open(f'{C}/{n}')))
f = lambda x, d=3: f'{float(x):.{d}f}'
L = []
P = rd('E01_lattigo_precision_sweep.csv'); T = rd('E02_lattigo_timing.csv'); K = rd('E02b_lattigo_collective_keygen.csv')
A = rd('E03_key_recovery_attack.csv'); FE = rd('E04_precision_budget_feasibility.csv'); MAC = rd('E05_mac_forgery_emulation.csv')
AB = rd('E06_selective_abort_exact.csv'); CV = rd('E07_conversion_leakage.csv'); SM = rd('E08_smudging_uniform_vs_gauss.csv')
R9 = rd('E09_rev9_statistics.csv')[0]; MS = rd('E10_mascot_end_to_end.csv'); TA = rd('E11_mascot_tampering.csv'); MR = rd('E12_mascot_modred_gadget.csv')[0]
S = json.load(open(sys.argv[3]))  # summary.json (model fits)
FITS = json.load(open(sys.argv[4]))

def table(cap, cols, rows, spec=None, small=True):
    spec = spec or 'l' * len(cols)
    L.append(r'\begin{table}[H]\centering' + (r'\small' if small else '') + rf'\caption{{{cap}}}' + '\n' + rf'\begin{{tabular}}{{{spec}}}\toprule')
    L.append(' & '.join(cols) + r'\\\midrule')
    for r in rows: L.append(' & '.join(str(x) for x in r) + r'\\')
    L.append(r'\bottomrule\end{tabular}\end{table}')
def fig(fn, cap, w='.8'):
    L.append(rf'\begin{{figure}}[H]\centering\includegraphics[width={w}\linewidth]{{figures/{fn}}}\caption{{{cap}}}\end{{figure}}')

L.append(r"""\documentclass[11pt,a4paper]{article}
\usepackage[margin=2.2cm]{geometry}\usepackage{booktabs,graphicx,float,amsmath,amssymb,longtable,hyperref,xcolor}
\hypersetup{hidelinks}\renewcommand{\thefigure}{S\arabic{figure}}\renewcommand{\thetable}{T\arabic{table}}\usepackage{url}
\title{MAVERICK-CKKS\\[2pt]\large Supplementary Material: Experiments Conducted, Code, Data and Results}
\author{Companion to the JISA manuscript (Revision 11)}\date{15 November 2026}
\begin{document}\maketitle
\begin{abstract}\noindent This document records every experiment behind the manuscript: its objective, platform, procedure, exact command, raw-data file, results and figure. Twelve experiment groups were run. Four used real cryptographic software: Lattigo v6.1.1 multiparty CKKS, and MP-SPDZ v0.4.0 MASCOT with separate party processes over TLS/TCP. Five used exact or Monte-Carlo arithmetic, and one is a statistical re-analysis of the earlier prototype. Every table here is generated from the CSV files in \texttt{results\_csv/}.\end{abstract}
\tableofcontents\newpage
\section{Environment}
\begin{itemize}
\item Hardware: 2-vCPU Intel Xeon @ 2.30\,GHz virtual machine, 7\,GB RAM, Linux.
\item Software: Go 1.24.7 with Lattigo v6.1.1; MP-SPDZ v0.4.0 official static binaries (\texttt{mascot-party.x}); Python 3.13 with NumPy, SciPy and Matplotlib.
\item Every random generator is seeded. In the MASCOT runs every party is a separate OS process communicating over TLS-authenticated TCP on localhost.
\item CKKS parameters stay within the 128-bit bounds of the Homomorphic Encryption Standard: $\log_2 q = 95, 175, 300, 580$ for $N = 2^{12}$ to $2^{15}$; 60 for the MASCOT pipeline; 180 and 360 for the feasibility runs.
\end{itemize}
\section{Experiment catalogue}
\begin{table}[H]\centering\small\caption{Experiments conducted.}
\begin{tabular}{llllll}\toprule
ID & Objective & Platform & Kind & Data & Figure\\\midrule
E1 & Precision vs.\ smudging, 4 modes & Lattigo & real & E01 & S1, S2\\
E2 & Share cost, bytes, key generation & Lattigo & real & E02, E02b & S3\\
E3 & Key recovery without smudging & Lattigo & real & E03 & --\\
E4 & Precision-budget validation & Lattigo & real & E04 & --\\
E5 & MAC soundness across field sizes & Python & emulation & E05 & S4\\
E6 & Selective-abort smudging loss & Python & exact & E06 & S5\\
E7 & Conversion / masked-reduction leakage & Python & exact & E07 & S6\\
E8 & Uniform vs.\ Gaussian smudging & Python & exact & E08 & --\\
E9 & Re-analysis of Revision 9 counts & Python & Monte Carlo & E09 & S7\\
E10 & End-to-end $\Pi_{\mathrm{MAV}}$ (KeyGen + Dec) & MASCOT + Lattigo & real & E10 & S8--S10\\
E11 & Active tampering of key shares & MASCOT & real & E11 & S11\\
E12 & Multi-limb masked reduction & MASCOT & real & E12 & --\\\bottomrule
\end{tabular}\end{table}
\section{Code map}
\begin{table}[H]\centering\small\caption{Code included in \texttt{code/}.}
\begin{tabular}{p{6.2cm}p{9cm}}\toprule
File & Purpose\\\midrule
\texttt{lattigo\_harness/main.go} & E1--E4: multiparty CKKS, four noise modes, key-recovery attack, feasibility\\
\texttt{python\_experiments/py\_experiments.py} & E5--E9: MAC emulation, abort TV, conversion, smudging, Rev.\,9 statistics\\
\texttt{python\_experiments/analyze.py} & Model fits and figures S1--S7\\
\texttt{mpc/mpspdz\_programs/keygen.mpc} & $\Pi_{\mathrm{MAV}}$ key generation inside MASCOT\\
\texttt{mpc/mpspdz\_programs/decrypt.mpc} & $\Pi_{\mathrm{MAV}}$ decryption with joint uniform noise\\
\texttt{mpc/mpspdz\_programs/verify.mpc} & Integrity probe used by the tampering test\\
\texttt{mpc/mpspdz\_programs/modred.mpc} & Masked modular-reduction gadget (two RNS limbs)\\
\texttt{mpc/mpspdz\_programs/mavcommon.py}, \texttt{mpc/nttlib.py} & In-MPC negacyclic NTT, random-bit noise, I/O helpers\\
\texttt{mpc/glue/main.go} & Lattigo glue: import MPC public key, encrypt/evaluate, decode\\
\texttt{mpc/pipeline.py}, \texttt{mpc/tamper.py} & Orchestration of E10 and E11\\
\texttt{figures\_and\_tables/*.py} & MASCOT figures, CSV export, this report, manuscript tables\\\bottomrule
\end{tabular}\end{table}
""")

# ---------- E1
g = collections.defaultdict(list)
for r in P: g[(int(r['logN']), int(r['n']), r['mode'], float(r['logSigma']))].append(float(r['rmse']))
L.append(r"\section{E1: Precision of threshold decryption (Lattigo)}")
L.append(r"""\textbf{Objective.} Measure the decoded error of $n$-party CKKS decryption under four noise modes, and fit the closed-form model. \textbf{Procedure.} Collective public-key generation; encrypt two random complex vectors and add them; $n$-party decryption with mode \emph{none}, \emph{independent} (Lattigo KeySwitch, Gaussian noise per party), \emph{collab-gauss} or \emph{collab-unif} (one joint noise term split into uniform shares). The grid is $\log_2N\in\{12,13,14\}$, $n\in\{2,4,8,16\}$, $\log_2\sigma\in\{10,\dots,30\}$, five repetitions, 960 runs in total. \textbf{Command.} \texttt{./mav -exp precision -reps 5}.""")
pf = S['precision_fit']
L.append(rf"""\textbf{{Result.}} Regressing $\log_2$RMSE on $\tfrac12\log_2(\sigma_{{sm}}^2+\sigma_{{ct}}^2)$ and $\log_2N$ gives slope {pf['a']:.4f}, $N$-coefficient {pf['b']:.4f} and intercept {pf['c']:.3f}, against theory $1$, $0.5$ and $-40.5$, with $R^2={pf['r2']:.7f}$ over {pf['npts']} configurations. Using the theoretical coefficients, the maximum residual is {pf['max_abs_resid_theory']:.3f} bits.""")
rows = []
for n in [2, 4, 8, 16]:
    rows.append([n] + [f(S['gap'][f'{l}_{n}']) for l in [12, 13, 14]] + [f(0.5 * math.log2(n))])
table(r'Precision lost by independent vs.\ collaborative smudging (bits), $\sigma\ge2^{20}$.', ['$n$', '$N=2^{12}$', '$N=2^{13}$', '$N=2^{14}$', 'model $\\frac12\\log_2n$'], rows, 'rrrrr')
rows = []
for mode in ['none', 'independent', 'collab-gauss', 'collab-unif']:
    for ls in ([0.0] if mode == 'none' else [10.0, 20.0, 30.0]):
        rows.append([mode, int(ls) if mode != 'none' else '--'] + [f(math.log2(st.mean(g[(14, n, mode, ls)])), 2) for n in [2, 4, 8, 16]])
table(r'Mean $\log_2$RMSE at $N=2^{14}$ (five repetitions each).', ['mode', '$\\log_2\\sigma$', '$n=2$', '$n=4$', '$n=8$', '$n=16$'], rows, 'lrrrrr')
fig('fig01_precision.png', 'Decoded error versus per-party smudging, $N=2^{14}$.')
fig('fig02_gap.png', 'Independent-minus-collaborative precision gap with the $\\frac12\\log_2n$ model.', '.7')

# ---------- E2
L.append(r"\section{E2: Computation and communication (Lattigo)}")
L.append(r"""\textbf{Objective.} Per-party share-generation time, aggregation time and share size. \textbf{Procedure.} $\log_2N\in\{12,\dots,15\}$, $n\in\{2,3,4,8,16\}$, modes none / independent / collaborative; 15 repetitions; medians reported. The collaborative mode excludes the sampling protocol, whose cost is measured in E10. \textbf{Command.} \texttt{./mav -exp timing -reps 15}.""")
rows = []
for l in [12, 13, 14, 15]:
    d = {r['mode']: r for r in T if int(r['logN']) == l and int(r['n']) == 4}
    rows.append([l] + [f(d[m]['genMedMs']) for m in ['none', 'independent', 'collab-unif']] + [f(d['collab-unif']['aggMedMs']), d['none']['shareBytes']])
table('Median per-party cost at $n=4$ (ms) and share size (bytes).', ['$\\log_2N$', 'none', 'independent', 'collab.', 'aggregate', 'bytes'], rows, 'rrrrrr')
rows = [[r['logN'], r['n'], f(r['ms'], 1), r['shareBytes']] for r in K if int(r['n']) in (2, 16)]
table('Collective public-key generation (all parties, ms).', ['$\\log_2N$', '$n$', 'ms', 'share bytes'], rows, 'rrrr')
fig('fig03_timing.png', 'Per-party decryption-share generation time, $n=4$, median and IQR.', '.75')

# ---------- E3
L.append(r"\section{E3: Key recovery from a released decryption (Lattigo)}")
L.append(r"""\textbf{Objective.} Show that smudging is necessary. \textbf{Procedure.} $N=2^{12}$, $n=3$. The adversary re-encodes the released decoded vector with a 256-bit-precision encoder to obtain $z'$, computes $s'=(z'-c_0)c_1^{-1}$ in the NTT domain, and compares $s'$ with the true collective key. 20 trials per configuration. \textbf{Command.} \texttt{./mav -exp attack -reps 20}.""")
table('Key recovery results.', ['mode', '$\\log_2\\sigma$', 'trials', 'full recoveries', 'coeff.\\ match'], [[r['mode'], r['logSigma'], r['trials'], r['fullRecoveries'], f(r['meanCoeffMatch'], 2)] for r in A], 'lrrrr')

# ---------- E4
L.append(r"\section{E4: Precision-budget validation at large scale (Lattigo)}")
L.append(r"""\textbf{Objective.} Validate Proposition 2: statistically sufficient smudging consumes $\log_2E+\lambda+\frac32\log_2N$ bits of scale. \textbf{Procedure.} Exact uniform noise of $k=\lceil\log_2(NE)\rceil+\lambda$ bits, $n=3$, ten repetitions; the scale is chosen for about 23 output bits, plus a control at $\Delta=2^{60}$. \textbf{Command.} \texttt{./mav -exp feasible -reps 10}.""")
table('Measured vs.\\ predicted $\\log_2$RMSE.', ['$\\log_2N$', '$\\lambda$', '$k$', '$\\log_2\\Delta$', '$\\log_2 q$', 'measured', 'predicted'],
      [[r['logN'], r['lambda'], f(r['k'], 0), r['logScale'], f(r['logQ'], 0), f(r['log2RmseSmudged']), f(r['log2RmsePred'])] for r in FE], 'rrrrrrr')

# ---------- E5
L.append(r"\section{E5: MAC soundness across field sizes (emulation)}")
L.append(r"""\textbf{Objective.} Validate Lemma 6 (forgery probability $1/p$, abort independent of the secret) across field sizes, which MASCOT cannot vary (E11 covers the deployed field). \textbf{Procedure.} SPDZ MAC check with three parties. A corrupted party adds $\delta\ne0$ to its value share and $g\delta$ to its MAC share for a random guess $g$; $4\times10^5$ trials per field. \textbf{Command.} \texttt{python3 py\_experiments.py data/py\_results.json}.""")
table('Forgery rates (95\\% Clopper--Pearson interval).', ['$p$', 'trials', 'forged', 'rate', '$1/p$', 'CI low', 'CI high'],
      [[r['p'] if int(r['p']) < 10**6 else f"$2^{{{float(r['log2p']):.0f}}}-1$", r['trials'], r['forged'], f"{float(r['rate']):.3g}", f"{float(r['predicted']):.3g}", f"{float(r['ci_lo']):.3g}", f"{float(r['ci_hi']):.3g}"] for r in MAC], 'rrrrrrr')
fig('fig04_mac.png', 'Accepted tampered openings versus field size with the $1/p$ model.', '.7')

# ---------- E6
L.append(r"\section{E6: Selective abort (exact computation)}")
L.append(r"""\textbf{Objective.} Validate Lemmas 4 and 5: value-dependent aborts condition the noise and weaken smudging. \textbf{Procedure.} Uniform noise on $2^k$ values; exact total-variation distances for six abort predicates and shifts $\delta\in\{1,2,4,16\}$.""")
table('Exact results for $k=16$ (bound: Lemma 5).', ['predicate', '$\\Pr[\\mathrm{acc}]$', 'TV to prior', 'TV $\\delta{=}1$', 'bound', 'TV $\\delta{=}4$'],
      [[r['predicate'].replace('>=', '$\\ge$').replace('<', '$<$').replace('=', '$=$') if False else r['predicate'], f(r['accept_prob'], 2), f(r['tv_to_prior'], 3), f"{float(r['tv_shift_1']):.2e}", f"{float(r['bound_shift_1']):.2e}", f"{float(r['tv_shift_4']):.2e}"] for r in AB if r['k'] == '16'], 'lrrrrr')
fig('fig05_abort.png', 'Smudging distance under abort predicates, $k=16$.')

# ---------- E7, E8
L.append(r"\section{E7: Conversion and masked-reduction leakage (exact)}")
L.append(r"""\textbf{Objective.} Leakage of the opened masked value versus the statistical parameter (Lemmas 7 and 9). The exact worst case is $(2^k-1)/2^{k+s}\le2^{-s}$.""")
table('Exact worst-case leakage, $k=20$.', ['$s$', 'TV (exact)', 'bound $2^{-s}$'], [[r['s'], f"{float(r['tv_worst']):.3e}", f"{float(r['bound']):.3e}"] for r in CV if r['k'] == '20'], 'rrr')
fig('fig06_conversion.png', 'Worst-case leakage of the masked modular reduction versus $\\sigma$.', '.7')
L.append(r"\section{E8: Uniform versus Gaussian smudging (exact)}")
table('Smudging distance at equal standard deviation.', ['$\\log_2\\sigma$', '$\\delta$', 'TV Gaussian', 'TV uniform', 'ratio'],
      [[r['log2sigma'], r['delta'], f"{float(r['tv_gauss']):.3e}", f"{float(r['tv_unif']):.3e}", f(float(r['tv_gauss']) / float(r['tv_unif']), 3)] for r in SM], 'rrrrr')

# ---------- E9
L.append(r"\section{E9: Statistical re-analysis of the Revision 9 prototype}")
ci = json.loads(R9['accept_ci'])
L.append(rf"""The earlier prototype recorded 120 draws of 8-bit noise, 96 distinct values and 59 sign-filtered acceptances. The expected number of distinct values is {f(R9['expected_distinct'],2)} (s.d.\ {f(R9['sd_distinct'],2)}). In $10^5$ simulations the 95\% interval was [{f(R9['sim_q025'],0)}, {f(R9['sim_q975'],0)}] and $\Pr[D\le96]={f(R9['pct_le_96'],3)}$. For 59/120 acceptances the exact 95\% interval is [{f(ci[0],3)}, {f(ci[1],3)}] (binomial $p={f(R9['binom_p'],2)}$). Both counts are consistent with ideal sampling. The prototype's 120/120 ``tamper detections'' came from a privileged oracle and are superseded by E11.""")
fig('fig07_rev9.png', 'Distinct-value distribution versus the recorded value.', '.7')

# ---------- E10
L.append(r"\section{E10: End-to-end actively secure $\Pi_{\mathrm{MAV}}$ (MP-SPDZ/MASCOT + Lattigo)}")
L.append(r"""\textbf{Objective.} Execute the malicious-secure construction end to end and check correctness, precision and cost.

\textbf{Procedure.}
\begin{enumerate}
\item A CRS polynomial $a$ is derived from a public seed.
\item \texttt{keygen.mpc} runs under MASCOT over $\mathbb F_{q_0}$, $q_0=2^{59}+2^{14}+1$. It samples a ternary $s$ and 4-bit uniform $e$ from authenticated random bits, applies the in-MPC negacyclic NTT, opens only $\hat p=\hat e-\hat a\odot\hat s$, and persists the authenticated $\hat s$.
\item The Lattigo glue imports $\mathsf{pk}$, encrypts two random vectors and adds them ($N=2^{12}$, $\Delta=2^{56}$).
\item \texttt{decrypt.mpc} samples $k$-bit uniform noise from authenticated bits and opens only $\hat z=\hat c_0+\hat c_1\odot\hat s+\hat e$.
\item Lattigo decodes the result and compares it with the plaintext.
\end{enumerate}
\textbf{Commands.} \texttt{python3 pipeline.py 2 4 n2\_val}; \texttt{pipeline.py 2 34,44 n2\_main}; \texttt{pipeline.py 2 46 n2\_lam20}; \texttt{pipeline.py 3 44 n3\_main}.""")
N, LS = 4096, 56
v = [r for r in MS if r['stage'] == 'decrypt' and r['k'] == '4'][0]; lsct = float(v['log2RMSE']) + LS - 5.5
def model(k): return 0.5 * math.log2((2**k / math.sqrt(12))**2 + 2**(2 * lsct)) + 5.5 - LS
rows = []
for r in MS:
    if r['stage'] == 'keygen': rows.append([r['n'], 'KeyGen', '--', r['random_bits'], f(r['mpc_time_s'], 0), f(r['global_MB'], 0), '--', '--'])
    else: rows.append([r['n'], 'Dec', r['k'], r['random_bits'], f(r['mpc_time_s'], 0), f(r['global_MB'], 0), f(r['log2RMSE']), f(model(int(r['k'])))])
table('All MASCOT runs (time and traffic as reported by MP-SPDZ). The $k=4$ run calibrates $\\log_2\\sigma_{ct}$ = ' + f(lsct, 2) + '.',
      ['$n$', 'stage', '$k$', 'random bits', 'time (s)', 'MB', '$\\log_2$RMSE', 'model'], rows, 'rlrrrrrr')
L.append(rf"""\textbf{{Result.}} Every run completed with all MAC checks passing and decoded correctly. Linear fits of time against random bits give {FITS['bits_per_s']['2']:.0f} bits/s with two parties and {FITS['bits_per_s']['3']:.0f} bits/s with three. The rigorous statistical security (Lemma 8) is $\lambda=8$, 18 and 20 for $k=34$, 44 and 46.""")
fig('fig08_mascot_precision.png', 'Precision of actively secure decryption versus $k$ with the model; labels give the rigorous $\\lambda$.')
fig('fig09_mascot_cost.png', 'MASCOT time versus authenticated random bits, with linear fits.', '.78')
fig('fig11_mascot_tradeoff.png', 'Security versus precision at a single 60-bit prime: model curve and measured points.', '.78')

# ---------- E11
L.append(r"\section{E11: Active tampering under MASCOT}")
L.append(r"""\textbf{Objective.} Show that malicious modification of authenticated shares is detected. \textbf{Procedure.} A random corrupted party modifies its persisted authenticated share of a random NTT coefficient of $\hat s$: the value $+\delta$, the MAC $+\delta'$, or both $(\delta,g\delta)$ with a guessed MAC key. The parties then run \texttt{verify.mpc}, which opens $\sum\rho_i\hat s_i+u$. There are ten runs per variant per $n$; party logs are scanned for \texttt{MacCheck Failure} (per run for $n=2$). \textbf{Command.} \texttt{python3 tamper.py <n> 10 <tag>}.""")
rows = []
for n in ['2', '3']:
    for k in ['control', 'value', 'mac', 'both']:
        rs = [r for r in TA if r['n'] == n and r['kind'] == k]
        rows.append([n, k, len(rs), sum(r['accepted'] == 'True' for r in rs), sum(r['mac_msg'] == 'True' for r in rs) if n == '2' else '--'])
table('Tampering outcomes.', ['$n$', 'variant', 'runs', 'accepted', 'MacCheck logged'], rows, 'rlrrr')
fig('fig10_mascot_tamper.png', 'Tampering outcomes: every attack aborted, every control accepted.', '.75')

# ---------- E12
L.append(r"\section{E12: Multi-limb masked modular reduction under MASCOT}")
L.append(rf"""\textbf{{Objective.}} Validate Algorithm 3 and Lemma 9 for decryption moduli with several RNS primes. \textbf{{Procedure.}} 128-bit prime field, two parties. Party 0 inputs 256 secret integers $|x|<2^{{73}}$; for two 60-bit RNS primes the parties open $y=x+\text{{shift}}+q_\ell R$, with $R$ built from 56 authenticated random bits ($\sigma=40$). \textbf{{Result.}} {int(MR['limb0_correct'])+int(MR['limb1_correct'])} of {int(MR['limb0_n'])+int(MR['limb1_n'])} residues were correct; {f(MR['mpc_time_s'],0)}\,s and {f(MR['global_MB'],0)}\,MB. An emulation with a field below the size requirement gave 75\% wrong residues.""")

L.append(r"""\section{Reproduction}
\begin{enumerate}
\item Lattigo experiments: in \texttt{code/lattigo\_harness} run \texttt{go build -o mav .} (with \texttt{GOFLAGS=-mod=mod} \texttt{GOPROXY=direct} \texttt{GOSUMDB=off} if module mirrors are blocked), then the commands listed in E1--E4.
\item Python experiments: \texttt{python3 code/python\_experiments/py\_experiments.py data/py\_results.json}, then \texttt{analyze.py data figures}.
\item MASCOT: install MP-SPDZ v0.4.0, copy \texttt{code/mpc/mpspdz\_programs/*} to \texttt{Programs/Source}, compile with \texttt{./compile.py -P 576460752303439873 keygen 4096} (and \texttt{decrypt 4096 <k>}, \texttt{verify 4096}), then run \texttt{pipeline.py} and \texttt{tamper.py}.
\item Regenerate figures, CSVs and this report with the scripts in \texttt{code/figures\_and\_tables/}.
\end{enumerate}
\end{document}""")
open(OUT, 'w').write('\n'.join(L))
print('ok')
