"""Figures for the actively secure (MP-SPDZ/MASCOT) experiments. Reads mpc/runs logs."""
import json, math, os, sys
import numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R = sys.argv[1]; FIG = sys.argv[2]
C = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']; INK, INK2 = '#0b0b0b', '#52514e'
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#e4e3df',
                     'grid.linewidth': .6, 'legend.frameon': False, 'font.family': 'serif', 'savefig.bbox': 'tight', 'figure.dpi': 200,
                     'axes.edgecolor': INK2, 'xtick.color': INK2, 'ytick.color': INK2})
N, LOGS = 4096, 56
runs = []
for t in ['n2_val', 'n2_main', 'n2_lam20', 'n3_main']:
    runs += [json.loads(l) for l in open(f'{R}/{t}/log.jsonl')]
dec = [r for r in runs if r['stage'] == 'decrypt']
lsct = [r for r in dec if r['k'] == 4][0]['log2RMSE'] + LOGS - (math.log2(N) - 1) / 2
def model(k): return 0.5 * math.log2((2**k / math.sqrt(12))**2 + 2**(2 * lsct)) + (math.log2(N) - 1) / 2 - LOGS
Bn, Bpk, c = 19.2, 8, 2
def E(l): return math.sqrt(2 * c * N * (Bpk**2 + Bn**2) * math.log(2 * N * 2**l)) + c * Bn
def lam_rig(k): return max([l for l in range(1, 80) if math.log2(N * E(l)) + l <= k] or [0])

# Fig 8: precision vs k, model + MASCOT points
fig, ax = plt.subplots(figsize=(5.6, 3.4))
ks = np.arange(0, 58, .5)
ax.plot(ks, [-model(k) for k in ks], color=INK2, lw=1, ls='--', label='Model (Prop. 2)')
for i, n in enumerate([2, 3]):
    p = [r for r in dec if r['n'] == n]
    ax.plot([r['k'] + 0.8 * i for r in p], [-r['log2RMSE'] for r in p], marker='os'[i], ms=7 - i, lw=0, color=C[i], mec='#fcfcfb',
            label=f'MASCOT, $n={n}$')
for r in [r for r in dec if r['n'] == 2 and r['k'] >= 34]:
    ax.annotate(f"$\\lambda$={lam_rig(r['k'])}", (r['k'], -r['log2RMSE']), xytext=(6, 4), textcoords='offset points', fontsize=7.5, color=INK)
ax.set_xlabel('Smudging noise bits $k$'); ax.set_ylabel('Correct bits ($-\\log_2$ RMSE)')
ax.set_title('Precision of actively secure threshold decryption ($N=2^{12}$, $\\Delta=2^{56}$)', fontsize=9, loc='left')
ax.legend(fontsize=7.5, loc='lower left'); fig.savefig(f'{FIG}/fig08_mascot_precision.png'); plt.close(fig)

# Fig 9: cost vs random bits (time), n=2 and n=3 with linear fits
fig, ax = plt.subplots(figsize=(5.4, 3.2))
allr = runs + [json.loads(l) for l in open(f'{R}/n2_val/log.jsonl')]
fits = {}
for i, n in enumerate([2, 3]):
    p = [r for r in runs if r['n'] == n]
    x = np.array([r['random_bits'] for r in p]) / 1000; y = np.array([r['mpc_time_s'] for r in p])
    ax.plot(x, y, marker='os'[i], ms=7 - i, lw=0, color=C[i], mec='#fcfcfb', label=f'$n={n}$ (KeyGen and Dec)')
    a, b = np.polyfit(x, y, 1); fits[n] = (a, b)
    xx = np.linspace(0, 200, 2); ax.plot(xx, a * xx + b, color=C[i], lw=1, alpha=.7)
    ax.text(196, a * 196 + b, f'{1000/a:.0f} bits/s', fontsize=7.5, color=INK, ha='right', va='bottom')
ax.set_xlabel('Authenticated random bits (thousands)'); ax.set_ylabel('MASCOT time (s)')
ax.set_title('Cost is linear in authenticated randomness', fontsize=9, loc='left'); ax.legend(fontsize=7.5, loc='upper left')
fig.savefig(f'{FIG}/fig09_mascot_cost.png'); plt.close(fig)

# Fig 10: tamper outcomes
tams = {n: json.load(open(f'{R}/n{n}_tamper/tamper.json')) for n in [2, 3]}
kinds = ['control', 'value', 'mac', 'both']; lab = ['No tampering', 'Value $+\\delta$', 'MAC $+\\delta^{\\prime}$', 'Both (guessed key)']
fig, ax = plt.subplots(figsize=(5.4, 2.9))
w = .38; x = np.arange(4)
for i, n in enumerate([2, 3]):
    S = tams[n]['summary']
    acc = [S[k]['accepted'] for k in kinds]; rej = [S[k]['trials'] - S[k]['accepted'] for k in kinds]
    ax.bar(x + (i - .5) * w, acc, w * .95, color=C[2], label='Accepted' if i == 0 else None)
    ax.bar(x + (i - .5) * w, rej, w * .95, bottom=acc, color=C[1], label='Aborted (MAC check)' if i == 0 else None)
    for j in range(4): ax.text(x[j] + (i - .5) * w, 10.3, f'$n$={n}', ha='center', fontsize=7, color=INK2)
ax.set_xticks(x); ax.set_xticklabels(lab, fontsize=8); ax.set_ylabel('Executions'); ax.set_ylim(0, 14)
ax.set_title('Active tampering of authenticated key shares (10 runs per bar)', fontsize=9, loc='left')
ax.legend(fontsize=7.5, loc='upper center', ncol=2); fig.savefig(f'{FIG}/fig10_mascot_tamper.png'); plt.close(fig)

# Fig 11: security-precision-time trade-off for n=2 (measured points + model curve)
fig, ax = plt.subplots(figsize=(5.4, 3.2))
lam = [l for l in range(4, 41) if math.ceil(math.log2(N * E(l))) + l <= 59]
kk = [int(math.ceil(math.log2(N * E(l)))) + l for l in lam]
ax.plot(lam, [-model(k) for k in kk], color=C[0], lw=2, label='Correct bits at $\\Delta=2^{56}$ (model)')
pts = [r for r in dec if r['n'] == 2 and r['k'] >= 34]
ax.plot([lam_rig(r['k']) for r in pts], [-r['log2RMSE'] for r in pts], 'o', color=C[1], ms=7, mec='#fcfcfb', label='MASCOT measured, $n=2$')
ax.axhline(0, color=INK2, lw=.8)
ax.axvspan(lam[-1], 41, color='#e4e3df', lw=0)
ax.text(lam[-1] + .5, 12, 'noise exceeds\n$q_0$ headroom;\nneeds multi-limb', fontsize=7.5, color=INK)
ax.set_xlim(3, 41)
ax.set_xlabel('Rigorous statistical security $\\lambda$ (Lemma 8)'); ax.set_ylabel('Correct bits')
ax.set_title('Security versus precision, single 60-bit prime', fontsize=9, loc='left'); ax.legend(fontsize=7.5)
fig.savefig(f'{FIG}/fig11_mascot_tradeoff.png'); plt.close(fig)
json.dump({'bits_per_s': {n: 1000 / fits[n][0] for n in fits}, 'fixed_s': {n: fits[n][1] for n in fits}}, open(f'{FIG}/mascot_fits.json', 'w'))
print({n: (round(1000 / fits[n][0]), round(fits[n][1], 1)) for n in fits})
