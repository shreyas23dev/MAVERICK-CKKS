"""Generate mascot_numbers.tex, mascot_runs.tex and mascot_tamper.tex from MASCOT run logs."""
import json, math, os, sys
OUT = sys.argv[1]; R = sys.argv[2]; WRAP = sys.argv[3]  # out dir, mascot runs dir, modred_wrap.json
N = 4096; LOGSCALE = 56

def load(tag):
    p = f'{R}/{tag}/log.jsonl'
    return [json.loads(l) for l in open(p)] if os.path.exists(p) else []

runs = load('n2_val') + load('n2_main') + load('n2_lam20') + load('n3_main')
B, Bpk, c = 19.2, 8, 2
def E(lam): return math.sqrt(2 * c * N * (Bpk**2 + B**2) * math.log(2 * N * 2**lam)) + c * B
def lam_rig(k): return max([l for l in range(1, 80) if math.log2(N * E(l)) + l <= k] or [0])

val = [r for r in runs if r['stage'] == 'decrypt' and r['k'] == 4][0]
log_sct = val['log2RMSE'] + LOGSCALE - (math.log2(N) - 1) / 2
rows, devs = [], []
for r in runs:
    if r['stage'] == 'keygen':
        rows.append((r['n'], 'KeyGen', '--', '--', r['random_bits'], r['mpc_time_s'], r['global_MB'], '--', '--')); continue
    k = r['k']
    pred = 0.5 * math.log2((2**k / math.sqrt(12))**2 + 2**(2 * log_sct)) + (math.log2(N) - 1) / 2 - LOGSCALE
    if k > 4: devs.append(abs(r['log2RMSE'] - pred))
    lam_h = k - math.log2(N * 6 * 2**log_sct)
    lamstr = '--' if k == 4 else f'{lam_rig(k)} / {lam_h:.0f}'
    rows.append((r['n'], 'Dec', k, lamstr, r['random_bits'], r['mpc_time_s'], r['global_MB'], f"{r['log2RMSE']:.3f}", f'{pred:.3f}'))
seen = set(); uniq = []
for x in rows:
    key = (x[0], x[1], x[2])
    if x[1] == 'KeyGen' and key in seen: continue
    seen.add(key); uniq.append(x)
uniq.sort(key=lambda x: (x[0], x[1] != 'KeyGen', x[2] if x[2] != '--' else 0))

with open(f'{OUT}/mascot_runs.tex', 'w') as f:
    f.write(r"""\begin{table}[t]\caption{End-to-end $\Pi_{\mathrm{MAV}}$ runs with MP-SPDZ/MASCOT (separate party processes) and Lattigo; $N=2^{12}$, $q_0$ 60-bit, $\Delta=2^{56}$. $\lambda$: rigorous (\cref{lem:hoeff}) / heuristic ($E=6\sigma_{\mathrm{ct}}$). The $k=4$ run calibrates $\sigma_{\mathrm{ct}}$. Time and traffic as reported by MP-SPDZ, including preprocessing.}\label{tab:mascot}\centering\footnotesize\setlength{\tabcolsep}{4pt}
\begin{tabular}{rlrlrrrrr}\toprule
$n$ & Stage & $k$ & $\lambda$ & bits & time (s) & MB & $\log_2$RMSE & model\\\midrule
""")
    for x in uniq:
        f.write(' & '.join(str(v) if not isinstance(v, float) else f'{v:.0f}' for v in x) + r'\\' + '\n')
    f.write(r"""\bottomrule\end{tabular}\end{table}""" + '\n')

def rate(n, field='q0'):
    rs = [r for r in runs if r['n'] == n and r['stage'] == 'decrypt' and r['k'] >= 34]
    if not rs: return None, None
    bits = sum(r['random_bits'] for r in rs); t = sum(r['mpc_time_s'] for r in rs); mb = sum(r['global_MB'] for r in rs)
    return bits / t, mb * 1000 / bits

tams = {}
for nn, tg in [(3, 'n3_tamper'), (2, 'n2_tamper')]:
    p = f'{R}/{tg}/tamper.json'
    if os.path.exists(p): tams[nn] = json.load(open(p))
tam = tams.get(3)
mod = json.load(open(f'{R}/modred.json')) if os.path.exists(f'{R}/modred.json') else None
wrap = json.load(open(WRAP))
def dec_min(n, k):
    r = [x for x in runs if x['n'] == n and x['stage'] == 'decrypt' and x['k'] == k]
    return f"{r[0]['mpc_time_s']/60:.0f}" if r else '??'
r2, mb2 = rate(2); r3, mb3 = rate(3)
big_rate = (mod['limb0_n'] * 2 * 56 / mod['mpc_time_s']) if mod and mod.get('mpc_time_s') else 81.0
lam40_bits = (66 + 2 * 56) * N
M = dict(MaxDevBits=f'{max(devs):.3f}' if devs else '??', NtwoKfourRMSE=f"{{{val['log2RMSE']:.2f}}}", SigmaCtMascot=f'{log_sct:.2f}',
         BitRateTwo=f'{r2:.0f}' if r2 else '??', BitRateThree=f'{r3:.0f}' if r3 else '??',
         MBperbitTwo=f'{mb2:.1f}' if mb2 else '??', MBperbitThree=f'{mb3:.1f}' if mb3 else '??',
         NtwoKfourtyfourMin=dec_min(2, 44), NthreeKfourtyfourMin=dec_min(3, 44),
         LamFourtyBitsM=f'{lam40_bits/1e6:.2f}', BitRateBig=f'{big_rate:.0f}', LamFourtyHours=f'{lam40_bits/big_rate/3600:.1f}',
         ModredWrapPct=f"{100*wrap['small']/wrap['M']:.0f}")
if tams:
    att = acc = 0; macs = 0; macn = 0
    rows = []
    names = dict(control='No tampering (control)', value=r'Share value $+\delta$', mac=r'MAC share $+\delta^{\prime}$', both=r'Both, $(\delta,g\delta)$, guessed key $g$')
    for nn in sorted(tams):
        S = tams[nn]['summary']; res = tams[nn]['results']
        for k in ['control', 'value', 'mac', 'both']:
            rs = [r for r in res if r['kind'] == k]
            conf = sum(r['mac_msg'] for r in rs) if nn == 2 else None
            if k != 'control':
                att += len(rs); acc += sum(r['accepted'] for r in rs)
                if nn == 2: macs += conf; macn += len(rs)
            rows.append((nn, names[k], len(rs), sum(r['accepted'] for r in rs), '--' if conf is None else str(conf), S[k]['median_wall_s']))
    M.update(TamperTotal=str(att), TamperAttacks=str(att), TamperRejected=str(att - acc), TamperMacConfirmed=f'{macs}/{macn}')
    with open(f'{OUT}/mascot_tamper.tex', 'w') as f:
        f.write(r"""\begin{table}[t]\caption{Active tampering of persisted authenticated key shares under MASCOT (\texttt{verify} opening; random corrupted party and coefficient). ``MacCheck'': runs whose party logs record MP-SPDZ's \texttt{MacCheck Failure} (logged per run for $n=2$).}\label{tab:tamper}\centering\small
\begin{tabular}{rlrrrr}\toprule
$n$ & Variant & runs & accepted & MacCheck & median s\\\midrule
""")
        for x in rows:
            f.write(f"{x[0]} & {x[1]} & {x[2]} & {x[3]} & {x[4]} & {x[5]:.1f}" + r'\\' + '\n')
        f.write(r"\bottomrule\end{tabular}\end{table}" + '\n')
else:
    M.update(TamperTotal='??', TamperAttacks='??', TamperRejected='??', TamperMacConfirmed='??')
    open(f'{OUT}/mascot_tamper.tex', 'w').write('% tamper results pending\n')
if mod:
    M.update(ModredCorrect=str(mod['limb0_correct'] + mod['limb1_correct']), ModredTotal=str(mod['limb0_n'] + mod['limb1_n']), ModredSeconds=f"{mod['mpc_time_s']:.0f}")
else:
    M.update(ModredCorrect='??', ModredTotal='??', ModredSeconds='??')
with open(f'{OUT}/mascot_numbers.tex', 'w') as f:
    for k, v in M.items(): f.write(f'\\newcommand{{\\{k}}}{{{v}}}\n')
print(json.dumps(M, indent=1))
