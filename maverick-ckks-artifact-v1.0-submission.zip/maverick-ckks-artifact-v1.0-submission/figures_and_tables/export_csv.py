"""Export every experiment's raw results to CSV."""
import json, csv, os, sys
D = sys.argv[1]; M = sys.argv[2]; O = sys.argv[3]; os.makedirs(O, exist_ok=True)
def jl(p): return [json.loads(l) for l in open(p)]
def w(name, rows, cols=None):
    cols = cols or sorted({k for r in rows for k in r})
    with open(f'{O}/{name}', 'w', newline='') as f:
        g = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore'); g.writeheader()
        for r in rows: g.writerow({k: (json.dumps(v) if isinstance(v, (list, dict)) else v) for k, v in r.items()})
    print(name, len(rows))
w('E01_lattigo_precision_sweep.csv', jl(f'{D}/precision.jsonl'), ['logN', 'n', 'mode', 'logSigma', 'rep', 'rmse', 'maxerr', 'mae', 'logScale'])
T = jl(f'{D}/timing.jsonl')
w('E02_lattigo_timing.csv', [r for r in T if r['exp'] == 'timing'], ['logN', 'n', 'mode', 'genMedMs', 'aggMedMs', 'shareBytes', 'totalBytes', 'gen', 'agg'])
w('E02b_lattigo_collective_keygen.csv', [r for r in T if r['exp'] == 'ckg'], ['logN', 'n', 'ms', 'shareBytes', 'levels', 'logQP'])
w('E03_key_recovery_attack.csv', jl(f'{D}/attack.jsonl'), ['logN', 'n', 'mode', 'logSigma', 'trials', 'fullRecoveries', 'meanCoeffMatch'])
w('E04_precision_budget_feasibility.csv', jl(f'{D}/feasible.jsonl'), ['logN', 'logScale', 'lambda', 'k', 'log2SigmaCt', 'log2RmseSmudged', 'log2RmsePred', 'bitsPrecision', 'logQ'])
P = json.load(open(f'{D}/py_results.json'))
w('E05_mac_forgery_emulation.csv', P['mac'], ['p', 'log2p', 'trials', 'forged', 'rate', 'predicted', 'ci_lo', 'ci_hi', 'honest_accept'])
w('E06_selective_abort_exact.csv', [dict(k=a['k'], predicate=a['predicate'], accept_prob=a['accept_prob'], tv_to_prior=a['tv_to_prior'], runs=a['runs'],
   **{f'tv_shift_{d}': a['shift_tv'][d] for d in a['shift_tv']}, **{f'bound_shift_{d}': a['shift_bound'][d] for d in a['shift_bound']}) for a in P['abort']])
w('E07_conversion_leakage.csv', P['conversion']['leakage'], ['k', 's', 'tv_worst', 'bound'])
w('E08_smudging_uniform_vs_gauss.csv', P['smudge'], ['log2sigma', 'delta', 'tv_gauss', 'tv_unif', 'gauss_approx'])
r9 = {k: v for k, v in P['rev9'].items() if k != 'hist'}; r9['accept_ci'] = json.dumps(r9['accept_ci'])
w('E09_rev9_statistics.csv', [r9])
runs = []
for t in ['n2_val', 'n2_main', 'n2_lam20', 'n3_main']: runs += jl(f'{M}/{t}/log.jsonl')
w('E10_mascot_end_to_end.csv', runs, ['tag', 'n', 'stage', 'k', 'random_bits', 'mpc_time_s', 'wall_s', 'global_MB', 'rc', 'log2RMSE', 'maxErr', 'pred_log2RMSE_smudge_only', 'time_utc'])
tam = []
for n in [2, 3]:
    for r in json.load(open(f'{M}/n{n}_tamper/tamper.json'))['results']: r['n'] = n; tam.append(r)
w('E11_mascot_tampering.csv', tam, ['n', 'kind', 'trial', 'party', 'index', 'accepted', 'rc', 'mac_msg', 'wall_s'])
w('E12_mascot_modred_gadget.csv', [json.load(open(f'{M}/modred.json'))])
