// MAVERICK-CKKS empirical harness (Lattigo v6.1.1).
// Real multiparty CKKS: collective public-key generation, encryption, homomorphic
// addition, and n-party decryption with four noise modes. Single host; parties are
// in-process objects; no network and no malicious-secure MPC is executed.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"math"
	"math/big"
	"math/bits"
	"math/rand"
	"os"
	"sort"
	"time"

	"github.com/tuneinsight/lattigo/v6/core/rlwe"
	"github.com/tuneinsight/lattigo/v6/multiparty"
	"github.com/tuneinsight/lattigo/v6/ring"
	"github.com/tuneinsight/lattigo/v6/schemes/ckks"
	"github.com/tuneinsight/lattigo/v6/utils/sampling"
)

type Rec map[string]interface{}

var out *json.Encoder

func emit(r Rec) { _ = out.Encode(r) }

func mkParams(logN int) ckks.Parameters {
	var lq []int
	switch logN {
	case 12:
		lq = []int{55, 40}
	case 13:
		lq = []int{55, 40, 40, 40}
	case 14:
		lq = []int{60, 40, 40, 40, 40, 40, 40}
	case 15:
		lq = []int{60, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40}
	}
	p, err := ckks.NewParametersFromLiteral(ckks.ParametersLiteral{LogN: logN, LogQ: lq, LogDefaultScale: 40})
	if err != nil {
		panic(err)
	}
	return p
}

type setup struct {
	params ckks.Parameters
	n      int
	sks    []*rlwe.SecretKey
	skSum  ring.Poly // NTT+Montgomery, sum of shares
	pk     *rlwe.PublicKey
	ecd    *ckks.Encoder
	tCKG   float64
	bCKG   int
}

func newSetup(params ckks.Parameters, n int) *setup {
	s := &setup{params: params, n: n}
	kg := ckks.NewKeyGenerator(params)
	rq := params.RingQ()
	s.skSum = rq.NewPoly()
	for i := 0; i < n; i++ {
		sk := kg.GenSecretKeyNew()
		s.sks = append(s.sks, sk)
		rq.Add(s.skSum, sk.Value.Q, s.skSum)
	}
	crs, _ := sampling.NewKeyedPRNG([]byte("maverick-crs"))
	ckg := multiparty.NewPublicKeyGenProtocol(params)
	crp := ckg.SampleCRP(crs)
	t0 := time.Now()
	agg := ckg.AllocateShare()
	for i := 0; i < n; i++ {
		sh := ckg.AllocateShare()
		ckg.GenShare(s.sks[i], crp, &sh)
		if i == 0 {
			agg = sh
		} else {
			ckg.AggregateShares(agg, sh, &agg)
		}
		s.bCKG = sh.BinarySize()
	}
	s.pk = rlwe.NewPublicKey(params)
	ckg.GenPublicKey(agg, crp, s.pk)
	s.tCKG = time.Since(t0).Seconds() * 1000
	s.ecd = ckks.NewEncoder(params)
	return s
}

// evaluated ciphertext ct = Enc(m1)+Enc(m2); returns ct and expected slots
func (s *setup) evalCt(rng *rand.Rand) (*rlwe.Ciphertext, []complex128) {
	slots := s.params.MaxSlots()
	m1 := make([]complex128, slots)
	m2 := make([]complex128, slots)
	want := make([]complex128, slots)
	for i := range m1 {
		m1[i] = complex(2*rng.Float64()-1, 2*rng.Float64()-1)
		m2[i] = complex(2*rng.Float64()-1, 2*rng.Float64()-1)
		want[i] = m1[i] + m2[i]
	}
	enc := ckks.NewEncryptor(s.params, s.pk)
	pt := ckks.NewPlaintext(s.params, s.params.MaxLevel())
	_ = s.ecd.Encode(m1, pt)
	c1, _ := enc.EncryptNew(pt)
	_ = s.ecd.Encode(m2, pt)
	c2, _ := enc.EncryptNew(pt)
	ev := ckks.NewEvaluator(s.params, nil)
	ct, _ := ev.AddNew(c1, c2)
	return ct, want
}

// uniform integer noise in [-W/2, W/2) written into an NTT-domain poly
func uniformNoiseNTT(rq *ring.Ring, logW float64, rng *rand.Rand, out ring.Poly) {
	W := math.Exp2(logW)
	N := rq.N()
	mod := rq.ModuliChain()
	kInt := int(math.Round(logW))
	exact := math.Abs(logW-float64(kInt)) < 1e-9 && kInt >= 1 && kInt <= 64
	if math.Abs(logW-float64(kInt)) < 1e-9 && kInt > 64 { // exact wide uniform via big integers
		half := new(big.Int).Lsh(big.NewInt(1), uint(kInt-1))
		for j := 0; j < N; j++ {
			u := new(big.Int)
			for b := 0; b < kInt; b += 64 {
				u.Lsh(u, 64).Or(u, new(big.Int).SetUint64(rng.Uint64()))
			}
			u.Rsh(u, uint((kInt+63)/64*64-kInt))
			u.Sub(u, half)
			for l, q := range mod {
				out.Coeffs[l][j] = new(big.Int).Mod(u, new(big.Int).SetUint64(q)).Uint64()
			}
		}
		rq.NTT(out, out)
		return
	}
	for j := 0; j < N; j++ {
		var mag uint64
		var neg bool
		if exact { // exact uniform on [-2^{k-1}, 2^{k-1}) for integer k <= 64
			u := rng.Uint64() >> (64 - uint(kInt))
			half := uint64(1) << uint(kInt-1)
			if u >= half {
				mag = u - half
			} else {
				mag, neg = half-u, true
			}
		} else {
			v := math.Floor(rng.Float64()*W - W/2)
			if v < 0 {
				mag, neg = uint64(-v), true
			} else {
				mag = uint64(v)
			}
		}
		for l := range mod {
			q := mod[l]
			r := mag % q
			if neg && r != 0 {
				r = q - r
			}
			out.Coeffs[l][j] = r
		}
	}
	rq.NTT(out, out)
}

// decrypt with mode; returns aggregated plaintext poly (NTT) and per-party share-gen times (ms)
func (s *setup) thresholdDecrypt(ct *rlwe.Ciphertext, mode string, logSigma float64, rng *rand.Rand) (ring.Poly, []float64, float64, int) {
	params := s.params
	rq := params.RingQ().AtLevel(ct.Level())
	times := make([]float64, s.n)
	var z ring.Poly
	var tAgg float64
	var bytes int
	switch mode {
	case "independent":
		sigma := math.Exp2(logSigma)
		cks := make([]multiparty.KeySwitchProtocol, s.n)
		for i := range cks {
			var err error
			cks[i], err = multiparty.NewKeySwitchProtocol(params, ring.DiscreteGaussian{Sigma: sigma, Bound: 6 * sigma})
			if err != nil {
				panic(err)
			}
		}
		zero := rlwe.NewSecretKey(params)
		shares := make([]multiparty.KeySwitchShare, s.n)
		for i := 0; i < s.n; i++ {
			shares[i] = cks[i].AllocateShare(ct.Level())
			t0 := time.Now()
			cks[i].GenShare(s.sks[i], zero, ct, &shares[i])
			times[i] = time.Since(t0).Seconds() * 1000
		}
		bytes = shares[0].BinarySize()
		t0 := time.Now()
		for i := 1; i < s.n; i++ {
			_ = cks[0].AggregateShares(shares[0], shares[i], &shares[0])
		}
		ksCt := ckks.NewCiphertext(params, 1, ct.Level())
		cks[0].KeySwitch(ct, shares[0], ksCt)
		tAgg = time.Since(t0).Seconds() * 1000
		z = ksCt.Value[0]
	default: // none, collab-unif, collab-gauss
		// F_VCS emulation: sample e once, split into uniform additive shares r_i in R_Q.
		r := make([]ring.Poly, s.n)
		e := rq.NewPoly()
		switch mode {
		case "collab-unif":
			uniformNoiseNTT(rq, logSigma+math.Log2(math.Sqrt(12)), rng, e) // std = 2^logSigma
		case "collab-gauss":
			prng, _ := sampling.NewPRNG()
			sigma := math.Exp2(logSigma)
			g, _ := ring.NewSampler(prng, rq, ring.DiscreteGaussian{Sigma: sigma, Bound: 6 * sigma}, false)
			g.Read(e)
			rq.NTT(e, e)
		}
		prng, _ := sampling.NewPRNG()
		us := ring.NewUniformSampler(prng, rq)
		acc := rq.NewPoly()
		for i := 0; i < s.n-1; i++ {
			r[i] = rq.NewPoly()
			us.Read(r[i])
			rq.Add(acc, r[i], acc)
		}
		r[s.n-1] = rq.NewPoly()
		rq.Sub(e, acc, r[s.n-1])
		shares := make([]ring.Poly, s.n)
		for i := 0; i < s.n; i++ {
			shares[i] = rq.NewPoly()
			t0 := time.Now()
			rq.MulCoeffsMontgomery(ct.Value[1], s.sks[i].Value.Q, shares[i])
			if mode != "none" {
				rq.Add(shares[i], r[i], shares[i])
			}
			times[i] = time.Since(t0).Seconds() * 1000
		}
		bytes = shares[0].BinarySize()
		t0 := time.Now()
		z = rq.NewPoly()
		z.Copy(ct.Value[0])
		for i := 0; i < s.n; i++ {
			rq.Add(z, shares[i], z)
		}
		tAgg = time.Since(t0).Seconds() * 1000
	}
	return z, times, tAgg, bytes
}

func (s *setup) decodeErr(z ring.Poly, ct *rlwe.Ciphertext, want []complex128) (float64, float64, float64) {
	pt := ckks.NewPlaintext(s.params, ct.Level())
	pt.Value.Copy(z)
	pt.Scale = ct.Scale
	got := make([]complex128, len(want))
	_ = s.ecd.Decode(pt, got)
	var sq, mx, sabs float64
	for i := range got {
		d := real(got[i]) - real(want[i])
		sq += d * d
		sabs += math.Abs(d)
		if math.Abs(d) > mx {
			mx = math.Abs(d)
		}
	}
	return math.Sqrt(sq / float64(len(got))), mx, sabs / float64(len(got))
}

func powmod(a, e, q uint64) uint64 {
	r := uint64(1)
	for e > 0 {
		if e&1 == 1 {
			hi, lo := bits.Mul64(r, a)
			_, r = bits.Div64(hi, lo, q)
		}
		hi, lo := bits.Mul64(a, a)
		_, a = bits.Div64(hi, lo, q)
		e >>= 1
	}
	return r
}

// Li--Micciancio-style linear key recovery from a released decryption.
// Adversary sees ct=(c0,c1) and the released decoded vector; it re-encodes it
// with a high-precision encoder to z', then sets s' = (z'-c0)/c1 in NTT domain.
func (s *setup) keyRecovery(ct *rlwe.Ciphertext, z ring.Poly) (bool, float64) {
	params := s.params
	rq := params.RingQ().AtLevel(ct.Level())
	// released output: decoded with bignum precision then re-encoded
	ecdHP := ckks.NewEncoder(params, 256)
	pt := ckks.NewPlaintext(params, ct.Level())
	pt.Value.Copy(z)
	pt.Scale = ct.Scale
	vals := make([]*bignumComplex, 0)
	_ = vals
	got := make([]complex128, params.MaxSlots())
	// Release path uses big-float decoding to remove float64 loss.
	bc := make([]*big.Float, 0)
	_ = bc
	_ = ecdHP.Decode(pt, got) // complex128 release (what an application publishes)
	pt2 := ckks.NewPlaintext(params, ct.Level())
	pt2.Scale = ct.Scale
	_ = ecdHP.Encode(got, pt2)
	zr := pt2.Value
	// s' = (z' - c0) * c1^{-1}
	diff := rq.NewPoly()
	rq.Sub(zr, ct.Value[0], diff)
	mod := rq.ModuliChain()
	rec := rq.NewPoly()
	for l, q := range mod {
		for j := 0; j < rq.N(); j++ {
			inv := powmod(ct.Value[1].Coeffs[l][j], q-2, q)
			hi, lo := bits.Mul64(diff.Coeffs[l][j], inv)
			_, rec.Coeffs[l][j] = bits.Div64(hi, lo, q)
		}
	}
	truth := rq.NewPoly()
	rq.IMForm(s.skSum, truth)
	rq.INTT(truth, truth)
	rq.INTT(rec, rec)
	match := 0
	for j := 0; j < rq.N(); j++ {
		if rec.Coeffs[0][j] == truth.Coeffs[0][j] {
			match++
		}
	}
	return match == rq.N(), float64(match) / float64(rq.N())
}

type bignumComplex struct{}

func median(x []float64) float64 {
	y := append([]float64{}, x...)
	sort.Float64s(y)
	m := len(y)
	if m%2 == 1 {
		return y[m/2]
	}
	return (y[m/2-1] + y[m/2]) / 2
}

func main() {
	exp := flag.String("exp", "precision", "precision|timing|attack")
	reps := flag.Int("reps", 5, "repetitions")
	flag.Parse()
	out = json.NewEncoder(os.Stdout)
	rng := rand.New(rand.NewSource(20261115))
	switch *exp {
	case "precision":
		for _, logN := range []int{12, 13, 14} {
			params := mkParams(logN)
			for _, n := range []int{2, 4, 8, 16} {
				s := newSetup(params, n)
				for _, mode := range []string{"none", "independent", "collab-gauss", "collab-unif"} {
					sig := []float64{0}
					if mode != "none" {
						sig = []float64{10, 15, 20, 25, 30}
					}
					for _, ls := range sig {
						for r := 0; r < *reps; r++ {
							ct, want := s.evalCt(rng)
							z, _, _, _ := s.thresholdDecrypt(ct, mode, ls, rng)
							rmse, mx, mae := s.decodeErr(z, ct, want)
							emit(Rec{"exp": "precision", "logN": logN, "n": n, "mode": mode, "logSigma": ls, "rep": r, "rmse": rmse, "maxerr": mx, "mae": mae, "logScale": 40})
						}
					}
				}
			}
		}
	case "timing":
		for _, logN := range []int{12, 13, 14, 15} {
			params := mkParams(logN)
			for _, n := range []int{2, 3, 4, 8, 16} {
				s := newSetup(params, n)
				emit(Rec{"exp": "ckg", "logN": logN, "n": n, "ms": s.tCKG, "shareBytes": s.bCKG, "levels": params.MaxLevel() + 1, "logQP": params.LogQP()})
				for _, mode := range []string{"none", "independent", "collab-unif"} {
					var gen, agg []float64
					var b int
					for r := 0; r < *reps; r++ {
						ct, _ := s.evalCt(rng)
						_, ts, ta, by := s.thresholdDecrypt(ct, mode, 30, rng)
						gen = append(gen, median(ts))
						agg = append(agg, ta)
						b = by
					}
					emit(Rec{"exp": "timing", "logN": logN, "n": n, "mode": mode, "genMedMs": median(gen), "gen": gen, "aggMedMs": median(agg), "agg": agg, "shareBytes": b, "totalBytes": b * n})
				}
			}
		}
	case "feasible":
		for _, cfg := range []struct{ logN, logScale, lam int }{{13, 93, 40}, {13, 73, 20}, {14, 95, 40}, {14, 75, 20}, {13, 60, 40}} {
			var lq []int
			if cfg.logN == 13 {
				lq = []int{60, 60, 60} // logQ = 180 <= 218 (HE Standard, 128-bit, ternary)
			} else {
				lq = []int{60, 60, 60, 60, 60, 60} // logQ = 360 <= 438
			}
			params, err := ckks.NewParametersFromLiteral(ckks.ParametersLiteral{LogN: cfg.logN, LogQ: lq, LogDefaultScale: cfg.logScale})
			if err != nil {
				panic(err)
			}
			s := newSetup(params, 3)
			// measure ciphertext noise without smudging to set E = 6 sigma_ct
			var r0 float64
			for r := 0; r < *reps; r++ {
				ct, want := s.evalCt(rng)
				z, _, _, _ := s.thresholdDecrypt(ct, "none", 0, rng)
				a, _, _ := s.decodeErr(z, ct, want)
				r0 += a / float64(*reps)
			}
			// fresh-encryption noise is scale-independent; take sigma_ct measured at Delta=2^40 (precision experiment)
			sct := map[int]float64{13: math.Exp2(9.69), 14: math.Exp2(10.18)}[cfg.logN] // n=3, measured at Delta=2^40 without P
			k := math.Ceil(float64(cfg.logN)+math.Log2(6*sct)) + float64(cfg.lam)
			ls := k - math.Log2(math.Sqrt(12))
			var r1 float64
			for r := 0; r < *reps; r++ {
				ct, want := s.evalCt(rng)
				z, _, _, _ := s.thresholdDecrypt(ct, "collab-unif", ls, rng)
				a, _, _ := s.decodeErr(z, ct, want)
				r1 += a / float64(*reps)
			}
			pred := ls + float64(cfg.logN-1)/2 - float64(cfg.logScale)
			emit(Rec{"exp": "feasible", "logN": cfg.logN, "logScale": cfg.logScale, "lambda": cfg.lam, "log2SigmaCt": math.Log2(sct), "k": k,
				"log2RmseNone": math.Log2(r0), "log2RmseSmudged": math.Log2(r1), "log2RmsePred": pred, "bitsPrecision": -math.Log2(r1), "logQ": params.LogQ()})
		}
	case "attack":
		params := mkParams(12)
		s := newSetup(params, 3)
		for _, cfg := range []struct {
			mode string
			ls   float64
		}{{"none", 0}, {"independent", 0}, {"independent", 5}, {"collab-unif", 5}, {"collab-unif", 20}, {"collab-unif", 30}} {
			succ := 0
			fr := 0.0
			for r := 0; r < *reps; r++ {
				ct, _ := s.evalCt(rng)
				z, _, _, _ := s.thresholdDecrypt(ct, cfg.mode, cfg.ls, rng)
				ok, f := s.keyRecovery(ct, z)
				if ok {
					succ++
				}
				fr += f
			}
			emit(Rec{"exp": "attack", "logN": 12, "n": 3, "mode": cfg.mode, "logSigma": cfg.ls, "trials": *reps, "fullRecoveries": succ, "meanCoeffMatch": fr / float64(*reps)})
		}
	}
	fmt.Fprintln(os.Stderr, "done", *exp)
}
